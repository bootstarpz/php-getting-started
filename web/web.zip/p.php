<?php 
			//if($_GET['p'] == 'about') {include "about.php";}
			$title = "Not Found";
			if(isset($_GET['terms'])) {$title = "Terms and Conditions";  }
			if(isset($_GET['privacy'])) { $title = "Privacy Policy"; }
			if(isset($_GET['about'])) {$title = "About Us";  }
			if(isset($_GET['request'])) {$title = "Request Custom ID Card";  }
			if(isset($_GET['wait'])) {$title = "Comming Soon...";  }
		   
			?>
<?php include "includez/header.php";?>
<!-- Section start -->
<div class="container-fluid">
   <div class="row">
      <div class="col-md-8">
         <div class="card">
            <div class="card-header card-header-primary">
               <h4 class="card-title"><?php echo $title;?></h4>
            </div>
            <div class="card-body" style="text-align: left;">
			
<div style="padding:10px">			
			<?php 
			//if($_GET['p'] == 'about') {include "about.php";}
			if(isset($_GET['404'])) {include "page/404.php"; }
			if(isset($_GET['terms'])) {include "page/terms.php"; }
			if(isset($_GET['privacy'])) {include "page/privacy.php"; }
			if(isset($_GET['about'])) {include "page/about.php"; }
			if(isset($_GET['request'])) {include "page/request.php"; }
			if(isset($_GET['wait'])) {include "page/wait.php"; }
		   
			?>
			   
</div>             

            </div>
         </div>
         <!-- Advertise Bottom-->
         <?php include "includez/ad-bottom.php";?>
         <!-- Advertise Bottom end-->
         <!-- Profile of Zorex --> 
         <?php include "includez/profile.php";?>		  
         <!-- Profile of Zorex -->   
      </div>
   </div>
   <!-- Advertise Side-->
   <?php include "includez/ad-side.php";?>
</div>
</div>
</div>
<?php  include "includez/footer.php";?>
