<?php $title = "BD Smart Card Back Part Maker - Make Smart Card Back Part Online";?>
<?php include "../includez/header.php";?>
<!-- Section start -->
<div class="container-fluid">
   <div class="row">
      <div class="col-md-8">
         <div class="card">
            <div class="card-header card-header-primary">
               <h4 class="card-title">BD Smart ID Back Part Maker</h4>
               <p class="card-category">Make Smart ID Card Back Part Online </p>
            </div>
            <!--Demo -->			
            <a data-toggle="modal" data-target="#idcard">
               <img  width="160px" height="50px" src="<?php echo $zorexid;?>/stylez/demo.png">
               <div class="ripple-container"></div>
            </a>
            <div class="modal fade" id="idcard" tabindex="-1" role="" style="display: none;" aria-hidden="true">
               <div class="modal-dialog modal-login" role="document">
                  <div class="modal-content">
                     <div class="">
                        <div class="modal-header">
                           <div class="card-header card-header-primary text-center">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                              x
                              </button>
                              <h4 class="card-title">Quick Demo</h4>
                           </div>
                        </div>
                        <div class="modal-body">				
                           <img  width="100%" height="100%" src="https://1.bp.blogspot.com/-mYaqB_zxWLw/XsPqBdRlFFI/AAAAAAAAAwM/ZLeMMOl-MDgwOLzh__t0FMumAYBk-gAmQCLcBGAsYHQ/s320/smart-back.jpg">              
                        </div>
                        <div class="modal-footer justify-content-center text">                    
                           <button class="btn btn-primary btn-round" data-dismiss="modal" aria-hidden="true" type="button">Close</button>                           
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--Demo -->	
            <div class="card-body" style="text-align: left;">
               <br>   
               <center>
                  <br>
                  <h4 style="color: red;" class="card-title"><i class="fa lock"></i> Link is Locked!</h4>
                  Please click the Subscribe button to get this link.<br>
                 
				 
				 
                  <br>
                 
				 <link rel="stylesheet" href="../stylez/lock/style.css">
<button class="btn_before btn btn-primary"">
Click this button to Show Lock
</button>
<div id="sociallocker">
<div id="sociallocker-links">
<div class="subscribe">
Subscribe to the channel to unlock link.<br/>
<div class="container row" data-sc="electrostepnetwork" data-yt="UCWsK8UkR2THYv28uZoN5xRg"><a class="subscribe-button yt-count" data-count="1M">
<svg xmlns="http://www.w3.org/2000/svg">
<g>
<rect class="plus__line1" width="2" height="12" x="5" y="0"></rect>
<rect class="plus__line2" width="12" height="2" x="0" y="5"></rect>
</g>
</svg><span class="subscribe-text">Subscribe</span></a></div>
</div>
</div>
<div id="sociallocker-content">
<a href="smart-back-hd">Click Here To Go</a>
</div>
<div id="sociallocker-overlay"><center><i class="fa unlock"></i> Subscribe To Unlock Link.</center></div>
</div>
<!-- partial -->
  <script src='https://code.jquery.com/jquery-3.2.1.min.js'></script>
  <script  src="../stylez/lock/script.js"></script>

				  
				  <br>
                  লিংক পেতে প্রথমে আমাদের চ্যানেলে Subscribe করুন,  তাহলে  Automatic link Unlock হবে। ওই লিংক থেকে আপনারা বানাতে পারবেন।
                  <br><br><br>
                  <img  width="100%" height="100%" src="https://1.bp.blogspot.com/-mYaqB_zxWLw/XsPqBdRlFFI/AAAAAAAAAwM/ZLeMMOl-MDgwOLzh__t0FMumAYBk-gAmQCLcBGAsYHQ/s320/smart-back.jpg">  
                  <br><br>






				  <br>
               </center>
            </div>
         </div>
         <!-- Advertise Bottom-->
         <?php include "../includez/ad-bottom.php";?>
         <!-- Advertise Bottom end-->
         <!-- Profile of Zorex --> 
         <?php include "../includez/profile.php";?>		  
         <!-- Profile of Zorex -->   
      </div>
   </div>
   <!-- Advertise Side-->
   <?php include "../includez/ad-side.php";?>
</div>
</div>
</div>
<?php  include "../includez/footer.php";?>
