<?php $title = "Facebook ID Card Maker - Make Fake Facebook ID Card Online";?>
<?php include "../includez/header.php";?>
<!-- Section start -->
<div class="container-fluid">
   <div class="row">
      <div class="col-md-8">
         <div class="card">
            <div class="card-header card-header-primary">
               <h4 class="card-title">Facebook ID Card Maker</h4>
               <p class="card-category">Make Fake Facebook ID Card Online </p>
            </div>
			<!--Demo -->			
            <a data-toggle="modal" data-target="#idcard">
               <img  width="160px" height="50px" src="<?php echo $zorexid;?>/stylez/demo.png">
               <div class="ripple-container"></div>
            </a>
            <div class="modal fade" id="idcard" tabindex="-1" role="" style="display: none;" aria-hidden="true">
               <div class="modal-dialog modal-login" role="document">
                  <div class="modal-content">
                     <div class="">
                        <div class="modal-header">
                           <div class="card-header card-header-primary text-center">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                              x
                              </button>
                              <h4 class="card-title">Quick Demo</h4>
                           </div>
                        </div>
                        <div class="modal-body">				
                           <img  width="100%" height="100%" src="https://1.bp.blogspot.com/-HFipb6wqKWU/XsPp_-ycd6I/AAAAAAAAAv4/elMoaKCVEzUPF5GN_7McuozIriSyK97RwCLcBGAsYHQ/s320/fbid.jpg">              
                        </div>
                        <div class="modal-footer justify-content-center text">                    
                           <button class="btn btn-primary btn-round" data-dismiss="modal" aria-hidden="true" type="button">Close</button>                           
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--Demo -->				
            <div class="card-body" style="text-align: left;">
               <?php
                  /*
                  	Coded By zorex zisa
                  	Contact With Me - http://fb.com/zorex.zisa
                  */
                  
                  if( isset($_POST['sub']))
                  {
                  	$nidnum = ipost("idnum");
                  	$urname = ipost("urname");
                  	$ngender = ipost("gender");
                  	$nbirth = ipost("birth");
                  	$adress = ipost("adress");
                  	$blood = ipost("blood");
                  	$sign = ipost("sign");
                  	$naddress = ipost("address");
					
					//Names of File
		$znam = "fbid-";
	    $num = $znam.date('is');
                  
                  	$error = array();
                  	$max_size = 3*1024*1024;
                  	$file_type = array('images/png','image/jpeg','image/jpg','image/gif');
                  	if( $_FILES['pic']['size'] > $max_size )
                  	{
                  			$error[] = "Max Image size is 3MB";
                  	}
                  	foreach ($file_type as $ft)
                  	{
                  		if( $_FILES['pic']['type'] == $ft )
                  		{
                  			$ftype = TRUE;
                  		}
                  	}
                  
                  	if( !@$ftype)
                  	{
                  		$error[] = "Your file is invalid ! Upload Only jpeg,png,gif,jpg images";
                  	}
                  	else
                  	{
                  		$gender = $num.".jpg";
                  		if( move_uploaded_file($_FILES['pic']['tmp_name'], "picz/".$gender))
                  		{
                  			$ban = $gender;
                  		}
                  	}
                  	if( !empty( $error))
                  	{
                  		foreach ($error as $err) 
                  		{
                  			echo "<div class='error'>$err</div>";
                  		}
                  		
                  	}
                  	else
                  	{
                  		include "../includez/Unicode2Bijoy.class.php";
                  		//
                  		// Fonts
                  		$bangla = "fonts/Myriad.ttf";
                  		$english = "fonts/Myriad.ttf";
                  		$sign_f = "fonts/RAG.ttf";
                  
                  		$idnum = Unicode2Bijoy::convert($nidnum);
                  		$gender = Unicode2Bijoy::convert($ngender);
                  		$birth = Unicode2Bijoy::convert($nbirth);
                  		$address = Unicode2Bijoy::convert($naddress);
                  
                  		$idno = rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9);
                  		$bg = $blood;
                  		
                  		$gimg="filez/fb.jpg";
                  
                  		$img=imagecreatefromjpeg($gimg);
                  
                  
                  
                  		//Your Image
                  		$imgSrc = "picz/".$ban;
                  		
                  		//SEAL
                  		$png = imagecreatefrompng('filez/mark-v.png');
                  		list($newwidth, $newheight) = getimagesize('filez/mark-v.png');   //xxxxxxxxxxx
                  
                  
                  		//getting the image dimensions
                  		list($width, $height) = getimagesize($imgSrc);
                  
                  		//saving the image into memory (for manipulation with GD Library)
                  		$myImage = imagecreatefromjpeg($imgSrc);
                  
                  		// calculating the part of the image to use for thumbnail
                  		if ($width > $height) {
                  		$y = 0;
                  		$x = ($width - $height) / 2;
                  		$smallestSide = $height;
                  		} else {
                  		$x = 0;
                  		$y = ($height - $width) / 2;
                  		$smallestSide = $width;
                  		}
                  
                  		// copying the part into thumbnail
                  		$thumbw = 200;
                  		$thumbh = 200;
                  		$thumb = imagecreatetruecolor($thumbw, $thumbh);
                  		imagecopyresampled($thumb, $myImage, 0, 0, $x, $y, $thumbw, $thumbh, $smallestSide, $smallestSide);
                  
                  		imagecopy($img, $thumb, 40, 40, 0, 0, 200, 200);
                  
                  		$color=imagecolorallocate($img, 0, 0, 0);
                  		$red = imagecolorallocate($img, 255, 0, 0);
                  
                  		imagefttext($img, 17, 0, 270, 125, $color, $bangla, $idnum);
                  
                  		imagefttext($img, 18, 0, 270, 173, $red, $english, $urname);
                  
                  		imagefttext($img, 17, 0, 270, 225, $color, $bangla, $gender);
                  
                  		imagefttext($img, 17, 0, 440, 225, $color, $bangla, $birth);
                  
                  		imagefttext($img, 17, 0, 270, 280, $color, $english, $adress);
                  
                           imagecopyresampled($img, $png, 134, 134, 0, 0, $newwidth, $newheight, $newwidth, $newheight);  //xxxxxx
                  
                  
                  		//header("Content-Type:image/jpeg");
                  		$f = "created/".$num.".jpg";
                  		imagejpeg($img, $f);
                  		imagedestroy($img);
                  		echo '
                  			<div class="icontent">
                  				<p>Your Card is Ready ! Please Download It From Below</p>
                  				<a href="'.$f.'"><img width="100%" src="'.$f.'" alt="zorex-nid" class="nid_pre" /></a>
                  				<a href="'.$f.'" download="fbid-zorexid.jpg"><center><br><button class="btn btn-primary pull-right text">Download</button></center></a>
                  			</div>
                  			';
                  	}
                  }
                  
                  else
                  {
                  
                  ?>
               <form action="" method="post" enctype="multipart/form-data">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Facebook ID Number</label>
                           <input name="idnum" type="text" class="form-control">
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Your Name</label>
                           <input name="urname" type="text" class="form-control">
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Date of Birth</label>
                           <input name="birth" type="text" class="form-control">
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-12">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Adress</label>
                           <input name="adress" type="text" class="form-control">
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Gender</label>
                           <select name="gender" id="gender" style="FONT-SIZE:12pt; WIDTH:200px; height:25px;" required="">
                              <option value="" selected="">Select</option>
                              <option value="Male">Male</option>
                              <option value="Female">Female</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Your Image</label>
                           <input type="file" name="pic" required="required"/>
                        </div>
                     </div>
                  </div>
<div class="g-ytsubscribe" data-channelid="UCL9pcMV_mgXNBNSKpBql8Fw" data-layout="default" data-count="hidden"></div>
<div class="fb-like" data-href="https://www.facebook.com/zorexzone" data-width="" data-layout="button" data-action="like" data-size="large" data-share="false"></div>

                  <button type="submit" name="sub" class="btn btn-primary pull-right">Create</button>
                  <div class="clearfix"></div>
               </form>
               <?php } ?>
            </div>
         </div>
         <!-- Advertise Bottom-->
         <?php include "../includez/ad-bottom.php";?>
         <!-- Advertise Bottom end-->
         <!-- Profile of Zorex --> 
         <?php include "../includez/profile.php";?>		  
         <!-- Profile of Zorex -->   
      </div>
   </div>
   <!-- Advertise Side-->
   <?php include "../includez/ad-side.php";?>
</div>
</div>
</div>
<?php  include "../includez/footer.php";?>
