<?php $title = "BD Smart ID Card Maker - Make Fake Bangladeshi Smart ID Card Online";?>
<?php include "../includez/header.php";?>
<!-- Section start -->
<div class="container-fluid">
   <div class="row">
      <div class="col-md-8">
         <div class="card">
            <div class="card-header card-header-primary">
               <h4 class="card-title">BD Smart ID Card Maker</h4>
               <p class="card-category">Make Fake Bangladeshi Smart ID Card Online </p>
            </div>
            <!--Demo -->			
            <a data-toggle="modal" data-target="#idcard">
               <img  width="160px" height="50px" src="<?php echo $zorexid;?>/stylez/demo.png">
               <div class="ripple-container"></div>
            </a>
            <div class="modal fade" id="idcard" tabindex="-1" role="" style="display: none;" aria-hidden="true">
               <div class="modal-dialog modal-login" role="document">
                  <div class="modal-content">
                     <div class="">
                        <div class="modal-header">
                           <div class="card-header card-header-primary text-center">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                              x
                              </button>
                              <h4 class="card-title">Quick Demo</h4>
                           </div>
                        </div>
                        <div class="modal-body">				
                           <img  width="100%" height="100%" src="https://1.bp.blogspot.com/-NjjiQ2p72tw/XsPqBiTGV3I/AAAAAAAAAwU/uG8Gp4vg_EAKd4DY7xIWg6NPgm5Q0ybWACLcBGAsYHQ/s320/smart-card.jpg">              
                        </div>
                        <div class="modal-footer justify-content-center text">                    
                           <button class="btn btn-primary btn-round" data-dismiss="modal" aria-hidden="true" type="button">Close</button>                           
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--Demo -->	
            <div class="card-body" style="text-align: left;">
               <?php
                  /*
                  	Coded By zorex zisa
                  	Contact With Me - http://fb.com/zorex.zisa
                  */
				  
//Delete				  
foreach (glob("picz/*") as $file1) {
	if (filemtime($file1)<time()-43200 && $file1!=="picz/view.php") { // older than 12hrs
		unlink($file1);
	}
}

foreach (glob("created/*") as $file2) {
	if (filemtime($file2)<time()-43200 && $file2!=="created/view.php") { // older than 12hrs
		unlink($file2);
	}
}
//Deleted	
                  
                  if( isset($_POST['sub']))
                  {
                  $nbname = ipost("bname");
                  $ename = ipost("ename");
                  $nfname = ipost("fname");
                  $nmname = ipost("mname");
                  $dob = ipost("dob");
                  $blood = ipost("blood");
                  $sign = ipost("sign");
                  $naddress = ipost("address");
				  
				  		//Names of File
		$znam = "smart-card-";
	    $num = $znam.date('is');
                  
                  $error = array();
                  $max_size = 3*1024*1024;
                  $file_type = array('images/png','image/jpeg','image/jpg','image/gif');
                  if( $_FILES['pic']['size'] > $max_size )
                  {
                  $error[] = "Max Image size is 3MB";
                  }
                  foreach ($file_type as $ft)
                  {
                  if( $_FILES['pic']['type'] == $ft )
                  {
                  $ftype = TRUE;
                  }
                  }
                  
                  if( !@$ftype)
                  {
                  $error[] = "Your file is invalid ! Upload Only jpeg,png,gif,jpg images";
                  }
                  else
                  {				  				  
                  $fname = $num.".jpg";
                  if( move_uploaded_file($_FILES['pic']['tmp_name'], "picz/".$fname))
                  {
                  $ban = $fname;
                  }
                  }
                  if( !empty( $error))
                  {
                  foreach ($error as $err) 
                  {
                  echo "<div class='error'>$err</div>";
                  }
                  
                  }
                  else
                  {
                  include "../includez/Unicode2Bijoy.class.php";
                  //
                  // Fonts
                  $banglab = "fonts/y.TTF";
                  $bangla = "fonts/x.TTF";
                  $english = "fonts/RobotoCondensed-Regular.ttf";
                  $englishbold = "fonts/RobotoCondensed-Bold.ttf";
                  $bold = "fonts/milf/milfb1.ttf";
                  $sign_f = "fonts/sign-3.ttf";
                  
                  $bname = Unicode2Bijoy::convert($nbname);
                  $fname = Unicode2Bijoy::convert($nfname);
                  $mname = Unicode2Bijoy::convert($nmname);
                  $address = Unicode2Bijoy::convert($naddress);
                  
                  $idno = rand(0,9).rand(0,9).rand(0,9).' '.rand(0,9).rand(0,9).rand(0,9).' '.rand(0,9).rand(0,9).rand(0,9).rand(0,9);
                  $bg = $blood;
                  
                  $gimg="filez/smart.jpg";
                  
                  $img=imagecreatefromjpeg($gimg);
                  
                  
                  
                  //Your Image
                  $imgSrc = "picz/".$ban;
                  
                  //SEAL
                  $png = imagecreatefrompng('filez/smart-effect.png');
                  list($newwidth, $newheight) = getimagesize('filez/smart-effect.png');   //xxxxxxx
                  
                  //face
                  $pngf = imagecreatefrompng('filez/facex.png');
                  list($newwidthf, $newheightf) = getimagesize('filez/facex.png');   //yyyyyy
                  
                  //getting the image dimensions
                  list($width, $height) = getimagesize($imgSrc);
                  
                  //saving the image into memory (for manipulation with GD Library)
                  $myImage = imagecreatefromjpeg($imgSrc);
                  
                  
                  //Make Black and White			
                  imagefilter($myImage, IMG_FILTER_GRAYSCALE); //first, convert to grayscale
                  //imagefilter($myImage, IMG_FILTER_CONTRAST, -10); //then, apply a full contrast
                  //imagefilter($myImage, IMG_FILTER_BRIGHTNESS, -50);
                  
                  // calculating the part of the image to use for thumbnail
                  if ($width > $height) {
                  $y = 0;
                  $x = ($width - $height) / 2;
                  $smallestSide = $height;
                  } else {
                  $x = 0;
                  $y = ($height - $width) / 2;
                  $smallestSide = $width;
                  }
                  
                  // copying the part into thumbnail
                  $thumbw = 228;
                  $thumbh = 285;
                  $thumb = imagecreatetruecolor($thumbw, $thumbh);
                  imagecopyresampled($thumb, $myImage, 0, 0, $x, $y, $thumbw, $thumbh, $smallestSide, $smallestSide);
                  
                  imagecopy($img, $thumb, 146, 289, 0, 0, 228, 285);
                  
                  $colorf=imagecolorallocate($img, 70, 68, 68);
                  $color=imagecolorallocate($img, 57, 61, 55);
                  $red = imagecolorallocate($img, 255, 0, 0);
                  
                  $black = imagecolorallocate($img, 65, 56, 61);
                  $black2 = imagecolorallocate($img, 31, 29, 34);
                  
                  imagefttext($img, 30, 0, 380, 335, $colorf, $banglab, $bname);
                  
                  imagefttext($img, 20, 0, 380, 396, $colorf, $englishbold, $ename);
                  
                  imagefttext($img, 30, 0, 380, 460, $colorf, $banglab, $fname);
                  
                  imagefttext($img, 30, 0, 380, 533, $colorf, $banglab, $mname);
                  
                  imagefttext($img, 25, 0, 495, 590, $black, $english, $dob);
                  
                  imagefttext($img, 30, 0, 493, 640, $black, $bold, $idno);
                  
                  imagefttext($img, 30, 0, 175, 631, $black2, $sign_f, $sign);
                  
                  //weblink
                  $webc = imagecolorallocate($img, 70, 68, 68);
                  $webf = "fonts/nr.ttf";
                  $web = "www.Zorexid.cu.ma";
                  imagefttext($img, 30, 0, 457, 53, $webc, $webf, $web);
                  
                  //little DoB
                  imagefttext($img, 15, 0, 805, 275, $colorf, $english, $dob);
                  
                  
                  //face
                  imagecopyresampled($img, $pngf, 136, 275, 0, 0, $newwidthf, $newheightf, $newwidthf, $newheightf);  //yyyyyy
                  
                  //seal
                  imagecopyresampled($img, $png, 108, 254, 0, 0, $newwidth, $newheight, $newwidth, $newheight);  //xxxxxx
                  
                  
                  //header("Content-Type:image/jpeg");				  
                  $f = "created/".$num.".jpg";
                  imagejpeg($img, $f);
                  imagedestroy($img);
                  echo '<div class="icontent">
                  				<p>Your Card is Ready ! Please Download It From Below</p>
                  				<a href="'.$f.'"><img width="100%" src="'.$f.'" alt="zorex-nid" class="nid_pre" /></a>
                  				<a href="'.$f.'" download="smart-card-zorexid.jpg"><center><br><button class="btn btn-primary pull-right text">Download</button></center></a>
                  			</div>';
                  
                  
                  }
                  }
                  
                  else
                  {
                  
                  ?>	
               <br>   
               <form action="" method="post" enctype="multipart/form-data">
                  <div class="row">
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Own name (in Bangla)</label>
                           <input name="bname" placeholder="নিজের নাম বাংলায় লিখুন " type="text" class="form-control">
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Own name (in English)</label>
                           <input  name="ename" placeholder="নিজের নাম ইংরেজিতে লিখুন" type="text" class="form-control">
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Father's name (Bangla)</label>
                           <input name="fname" placeholder="পিতার নাম বাংলায় লিখুন" type="text" class="form-control">
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Mother's name (Bangla)</label>
                           <input name="mname" placeholder="মায়ের নাম বাংলায় লিখুন" type="text" class="form-control">
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Date Of Birth (English)</label>
                           <input name="dob" placeholder="5 Jan, 1998" type="text" class="form-control">
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Signature (in English)</label>
                           <input name="sign"  placeholder="ইংরেজিতে ডাকনাম লিখুন" type="text" class="form-control">
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-12">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Your Image</label>
                           <input type="file" name="pic" required="required"/>
                        </div>
                     </div>
                  </div>
                  <input type="checkbox" name="checkbox" value="check" id="agree" required="required" /> I have read and agree to the <a href="#popup1" style="color: #1861bf;">Terms and Conditions</a>.<br><br> 
                  <?php include "../includez/terms.php";?>
                  <div class="g-ytsubscribe" data-channelid="UCL9pcMV_mgXNBNSKpBql8Fw" data-layout="default" data-count="hidden"></div>
                  <div class="fb-like" data-href="https://www.facebook.com/zorexzone" data-width="" data-layout="button" data-action="like" data-size="large" data-share="false"></div>
                  <button type="submit" name="sub" class="btn btn-primary pull-right">Create</button>
               </form>
               <?php } ?>
            </div>
         </div>
         <!-- Advertise Bottom-->
         <?php include "../includez/ad-bottom.php";?>
         <!-- Advertise Bottom end-->
         <!-- Profile of Zorex --> 
         <?php include "../includez/profile.php";?>		  
         <!-- Profile of Zorex -->   
      </div>
   </div>
   <!-- Advertise Side-->
   <?php include "../includez/ad-side.php";?>
</div>
</div>
</div>
<?php  include "../includez/footer.php";?>
