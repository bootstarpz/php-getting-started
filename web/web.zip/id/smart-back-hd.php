<?php $title = "BD Smart ID Card Maker - Make Fake Bangladeshi Smart ID Card Online";?>
<?php include "../includez/header.php";?>
<!-- Section start -->
<div class="container-fluid">
   <div class="row">
      <div class="col-md-8">
         <div class="card">
            <div class="card-header card-header-primary">
               <h4 class="card-title">BD Smart ID Card Maker</h4>
               <p class="card-category">Make Fake Bangladeshi Smart ID Card Online </p>
            </div>
            <!--Demo -->			
            <a data-toggle="modal" data-target="#idcard">
               <img  width="160px" height="50px" src="<?php echo $zorexid;?>/stylez/demo.png">
               <div class="ripple-container"></div>
            </a>
            <div class="modal fade" id="idcard" tabindex="-1" role="" style="display: none;" aria-hidden="true">
               <div class="modal-dialog modal-login" role="document">
                  <div class="modal-content">
                     <div class="">
                        <div class="modal-header">
                           <div class="card-header card-header-primary text-center">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                              x
                              </button>
                              <h4 class="card-title">Quick Demo</h4>
                           </div>
                        </div>
                        <div class="modal-body">				
                           <img  width="100%" height="100%" src="https://1.bp.blogspot.com/-mYaqB_zxWLw/XsPqBdRlFFI/AAAAAAAAAwM/ZLeMMOl-MDgwOLzh__t0FMumAYBk-gAmQCLcBGAsYHQ/s320/smart-back.jpg">              
                        </div>
                        <div class="modal-footer justify-content-center text">                    
                           <button class="btn btn-primary btn-round" data-dismiss="modal" aria-hidden="true" type="button">Close</button>                           
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--Demo -->	
            <div class="card-body" style="text-align: left;">
               <?php
                  /*
                  	Coded By zorex zisa
                  	Contact With Me - http://fb.com/zorex.zisa
                  */
                  
                  if( isset($_POST['idno']))
                  { 
                  $idnob =  ipost("idno");
                  $idnob = str_replace("&lt;", "<", $idnob);
                  } else {
                  //id no
                  $idno1 =rand(0,9).rand(0,9).rand(0,9);
                  $idno2 =rand(0,9).rand(0,9).rand(0,9);
                  $idno3 =rand(0,9).rand(0,9).rand(0,9);
                  $idno4 =rand(0,9);		  
                  $idno = $idno1.' '.$idno2.' '.$idno3.$idno4;				  
                  $idnob =  $idno1.$idno2.$idno3.'<'.$idno4;
                  }
                  
                  
                  //Delete				  
                  foreach (glob("picz/*") as $file1) {
                  if (filemtime($file1)<time()-43200 && $file1!=="picz/view.php") { // older than 12hrs
                  unlink($file1);
                  }
                  }
                  
                  foreach (glob("created/*") as $file2) {
                  if (filemtime($file2)<time()-43200 && $file2!=="created/view.php") { // older than 12hrs
                  unlink($file2);
                  }
                  }
                  //Deleted	
                  
                  if( isset($_POST['bplace']))
                  {
                  $nbname = ipost("bname");
                  $nbname = ipost("bname");
                  $ename = ipost("ename");
                  $nfname = ipost("fname");
                  $nmname = ipost("mname");
                  $dob = ipost("dob");
                  $sign = ipost("sign");
                  $naddress = ipost("address");
                  
                  //Back -------- 1
                  
                  
                  
                  $bplace = ipost("bplace");
                  $blood = ipost("blood");				  
                  $bottom = ipost("bottom");
                  
                  
                  $basa = ipost("basa");
                  $xbasa = "ঠিকানা: বাসা/হোল্ডিং: $basa";
                  
                  $gram = ipost("gram");
                  $xgram = "গ্রাম/রাস্তা: $gram,";
                  
                  $jela = ipost("jela");
                  $dak = ipost("dak");
                  $xdak = "ডাকঘর: $dak, $jela,";
                  
                  $xcitycorp = ipost("citycorp");
                  
                  
                  /*  
                  
                  $basa ="cvebv evwo";
                  $xbasa = "wVKvbv: evmv/nvwWs: $basa";
                  
                  $gram = "cvebvevwo";
                  $xgram = "evg/ivmv: $gram,";
                  
                  $jela = "cvebv evwo cvebvevwo";
                  $dak = "cvebvevwo - 2200";
                  $xdak = "WKNi: $dak, $jela,";
                  
                  $xcitycorp = "cvebv evwo cvebvevwo, cvebv";
                  */
                               
                  
                  //Names of File
                  $znam = "smart-back-";
                  $num = $znam.date('is');
                  
                  
                  include "../includez/Unicode2Bijoy.class.php";
                  //
                  // Fonts
                  $banglab = "fonts/y.TTF";
                  $bangla = "fonts/x.TTF";
                  $english = "fonts/RobotoCondensed-Regular.ttf";
                  $englishbold = "fonts/RobotoCondensed-Bold.ttf";
                  $bold = "fonts/milf/milfb1.ttf";
                  $sign_f = "fonts/sign-3.ttf";
                  
                  //Back -------- 2
                  $btmfont = "fonts/ocrb.otf";
                  
                  
                  
                  //Back -------- 3s	
                  $bname = Unicode2Bijoy::convert($nbname);
                  $fname = Unicode2Bijoy::convert($nfname);
                  $mname = Unicode2Bijoy::convert($nmname);
                  $address = Unicode2Bijoy::convert($naddress);
                  
                  
                  
                  $basa = Unicode2Bijoy::convert($xbasa);
                  $gram = Unicode2Bijoy::convert($xgram);
                  $dak = Unicode2Bijoy::convert($xdak); 
                  $citycorp = Unicode2Bijoy::convert($xcitycorp); 
                  
                  /*	//id no
                  $idno1 =rand(0,9).rand(0,9).rand(0,9);
                  $idno2 =rand(0,9).rand(0,9).rand(0,9);
                  $idno3 =rand(0,9).rand(0,9).rand(0,9);
                  $idno4 =rand(0,9);		  
                  $idno = $idno1.' '.$idno2.' '.$idno3.$idno4;				  
                  $idnob =  $idno1.$idno2.$idno3.'<'.$idno4.'0';
                  
                  */	  
                  
                  
                  $bg = $blood;                  
                  $gimg="filez/smart-back.jpg";                  
                  $img=imagecreatefromjpeg($gimg);
                  
                  
                   
                  //color			  
                  //$colorf=imagecolorallocate($img, 70, 68, 68);
                  $colorf=imagecolorallocate($img, 54, 55, 50);
                  //$colorbaname=imagecolorallocate($img, 46, 46, 44);
                  $colorb =imagecolorallocate($img, 51, 43, 40);
                  $color2 =imagecolorallocate($img, 39, 36, 29);
                  
                  
                  
                  $color=imagecolorallocate($img, 57, 61, 55);
                  $red = imagecolorallocate($img, 255, 0, 0);
                  
                  $black = imagecolorallocate($img, 65, 56, 61);
                  $black2 = imagecolorallocate($img, 31, 29, 34);
                  
                  
                  
                  //Back -------- 4
                  
                  $basagram = $basa.', '.$gram;
                  
                  imagefttext($img, 24, 0, 142, 304, $colorf, $banglab, $basagram);
                  imagefttext($img, 24, 0, 142, 330, $colorf, $banglab, $dak);
                  imagefttext($img, 24, 0, 142, 355, $colorf, $banglab, $citycorp);
                  
                  $idate ="18 Feb, 2017";
                  imagefttext($img, 20, 0, 255, 430, $red, $english, $blood);
                  imagefttext($img, 17, 0, 438, 430, $colorf, $englishbold, $bplace);
                  imagefttext($img, 17, 0, 831, 430, $colorf, $englishbold, $idate);
                  
                  $idnob = $idnob."0";
                  $btma = "I<BGD$idnob<<<<<<<<<<<<<";
                  $btmb = "9411014M3011146BGD<<<<<<<<<<<6";
                  $btmc = "";
                  
                  $btmfz="28";
                  
                  imagefttext($img, $btmfz, 0, 135, 531, $colorb, $btmfont, $btma);
                  imagefttext($img, $btmfz, 0, 135, 574, $colorb, $btmfont, $btmb);
                  
                  $bottom = str_replace("&lt;", "<", $bottom);
                  
                  imagefttext($img, $btmfz, 0, 135, 615, $colorb, $btmfont, $bottom);
               
                  //header("Content-Type:image/jpeg");				  
                  $f = "created/".$num.".jpg";
                  imagejpeg($img, $f);
                  imagedestroy($img);
                  echo '<div class="icontent">
                  				<p>Your Card is Ready ! Please Download It From Below</p>
                  				<a href="'.$f.'"><img width="100%" src="'.$f.'" alt="zorex-nid" class="nid_pre" /></a>
                  				<a href="'.$f.'" download="smart-back-zorexid.jpg"><center><br><button class="btn btn-primary pull-right text">Download</button></center></a>
                  			</div>';
                  }
                  else
                  {
                  
                  ?>	
               <br>   
               <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                  <!--Back -------- 5 -->
                  <div class="row">
                     <div class="col-md-12">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Smart Card Number <font color="red">(Optional)</font> </label>
                           <input name="idno" value="<?php echo $idnob ?>" value="RASEL<<MD<KAMRUL<HASAN<<<<<<<<" type="text" class="form-control">
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-4">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">বাসা/হোল্ডিং</label>
                           <input name="basa" value="মুন্সী বাড়ি" type="text" class="form-control">
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">গ্রাম/রাস্তা</label>
                           <input name="gram" value="রামপুর" type="text" class="form-control">
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">ডাকঘর</label>
                           <input name="dak" value="কোর্টবাড়ি - ৩৫০০" type="text" class="form-control">
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">জেলা</label>
                           <input name="jela" value="কুমিল্লা সদর দক্ষিণ" type="text" class="form-control">
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">সিটি কর্পোরেশন</label>
                           <input name="citycorp"  value="কুমিল্লা সিটি কর্পোরেশন, কুমিল্লা" type="text" class="form-control">
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Place Of Birth <font color="red">(English)</font></label>
                           <input name="bplace" value="Dhaka" type="text" class="form-control">
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Blood Group <font color="red">(in English)</font></label>
                           <input name="blood"  value="B+" type="text" class="form-control">
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-12">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Last Part <font color="red">(Within 30 letter)</font> </label>
                           
						   <input disabled  maxlength="3" size="3" value="30" id="counter">
<input name="bottom" onkeyup="textCounter(this,'counter',30);" value="FAHIM<<MD<KAMRUL<HASAN<<<<<<<<" type="text" id="message" class="form-control">
<script>
function textCounter(field,field2,maxlimit)
{
 var countfield = document.getElementById(field2);
 if ( field.value.length > maxlimit ) {
  field.value = field.value.substring( 0, maxlimit );
  return false;
 } else {
  countfield.value = maxlimit - field.value.length;
 }
}
</script>
                        </div>
                     </div>
                  </div>
                  <input type="checkbox" name="checkbox" value="check" id="agree" required="required" /> I have read and agree to the <a href="#popup1" style="color: #1861bf;">Terms and Conditions</a>.<br><br> 
                  <?php include "../includez/terms.php";?>
                 
                     <div class="g-ytsubscribe" data-channelid="UCL9pcMV_mgXNBNSKpBql8Fw" data-layout="default" data-count="hidden"></div>
                     <div class="fb-like" data-href="https://www.facebook.com/zorexzone" data-width="" data-layout="button" data-action="like" data-size="large" data-share="false"></div> 
                  <button type="submit" name="sub" class="btn btn-primary pull-right">Create</button>
               </form>
               <?php } ?>
            </div>
         </div>
         <!-- Advertise Bottom-->
         <?php include "../includez/ad-bottom.php";?>
         <!-- Advertise Bottom end-->
         <!-- Profile of Zorex --> 
         <?php include "../includez/profile.php";?>		  
         <!-- Profile of Zorex -->   
      </div>
   </div>
   <!-- Advertise Side-->
   <?php include "../includez/ad-side.php";?>
</div>
</div>
</div>
<?php  include "../includez/footer.php";?>
