<?php $title = "BD PNG Smart Card Maker - Make Fake Bangladeshi Transparent Smart ID Card Online";?>
<?php include "../includez/header.php";?>
<!-- Section start -->
<div class="container-fluid">
   <div class="row">
      <div class="col-md-8">
         <div class="card">
           <div class="card-header card-header-primary">
               <h4 class="card-title">BD PNG Smart Card Maker</h4>
               <p class="card-category">Make Transparent Bangladeshi Smart ID Card Online </p>
            </div>
            <!--Demo -->			
            <a data-toggle="modal" data-target="#idcard">
               <img  width="160px" height="50px" src="<?php echo $zorexid;?>/stylez/demo.png">
               <div class="ripple-container"></div>
            </a>
            <div class="modal fade" id="idcard" tabindex="-1" role="" style="display: none;" aria-hidden="true">
               <div class="modal-dialog modal-login" role="document">
                  <div class="modal-content">
                     <div class="">
                        <div class="modal-header">
                           <div class="card-header card-header-primary text-center">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                              x
                              </button>
                              <h4 class="card-title">Quick Demo</h4>
                           </div>
                        </div>
                        <div class="modal-body">				
                           <img  width="100%" height="100%" src="https://1.bp.blogspot.com/-tt4gBMaWHPg/XsPqBh--0HI/AAAAAAAAAwQ/-Umr3lVX9NwzyJo9tnuFeYKqMnTby4nEACLcBGAsYHQ/s320/smart-card-png.png">              
                        </div>
                        <div class="modal-footer justify-content-center text">                    
                           <button class="btn btn-primary btn-round" data-dismiss="modal" aria-hidden="true" type="button">Close</button>                           
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--Demo -->	
            <div class="card-body" style="text-align: left;">
               <br>   
               <center>
                  <h4 style="color: red;" class="card-title">Link is Hidden!</h4>
                  Please join our Facebook Group to get access in this link.<br>
                  <a style="color: blue;" href="https://www.facebook.com/groups/1545370242278237">
                     <h5>m.facebook.com/groups/zorexzone</h5>
                  </a>
                  <br>
                  <a href="https://www.facebook.com/groups/1545370242278237"><img style="width: 200px;" src="<?php echo $zorexid;?>/stylez/btn/1.png"></a><br><br>
                  লিংক আমাদের ফেসবুক গ্রুপে দেয়া আছে, ওই লিংক থেকে আপনারা বানাতে পারবেন। <br>Group a <font color="red">Auto Appruval on </font> করা,  তাই রিকোয়েস্ট দেয়ার সাখে সাথে accept হয়ে যাবে, ইনশা্ল্লাহ।
                  <br><br><br>
                  <img  width="100%" height="100%" src="https://1.bp.blogspot.com/-tt4gBMaWHPg/XsPqBh--0HI/AAAAAAAAAwQ/-Umr3lVX9NwzyJo9tnuFeYKqMnTby4nEACLcBGAsYHQ/s320/smart-card-png.png">  
                  <br><br><br>
               </center>
            </div>
         </div>
         <!-- Advertise Bottom-->
         <?php include "../includez/ad-bottom.php";?>
         <!-- Advertise Bottom end-->
         <!-- Profile of Zorex --> 
         <?php include "../includez/profile.php";?>		  
         <!-- Profile of Zorex -->   
      </div>
   </div>
   <!-- Advertise Side-->
   <?php include "../includez/ad-side.php";?>
</div>
</div>
</div>
<?php  include "../includez/footer.php";?>
