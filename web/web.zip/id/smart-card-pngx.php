<?php $title = "BD PNG Smart Card Maker - Make Fake Bangladeshi Transparent Smart ID Card Online";?>
<?php include "../includez/header.php";?>
<!-- Section start -->
<div class="container-fluid">
   <div class="row">
      <div class="col-md-8">
         <div class="card">
            <div class="card-header card-header-primary">
               <h4 class="card-title">BD PNG Smart Card Maker</h4>
               <p class="card-category">Make Transparent Bangladeshi Smart ID Card Online </p>
            </div>
            <!--Demo -->			
            <a data-toggle="modal" data-target="#idcard">
               <img  width="160px" height="50px" src="<?php echo $zorexid;?>/stylez/demo.png">
               <div class="ripple-container"></div>
            </a>
            <div class="modal fade" id="idcard" tabindex="-1" role="" style="display: none;" aria-hidden="true">
               <div class="modal-dialog modal-login" role="document">
                  <div class="modal-content">
                     <div class="">
                        <div class="modal-header">
                           <div class="card-header card-header-primary text-center">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                              x
                              </button>
                              <h4 class="card-title">Quick Demo</h4>
                           </div>
                        </div>
                        <div class="modal-body">				
                           <img  width="100%" height="100%" src="https://1.bp.blogspot.com/-tt4gBMaWHPg/XsPqBh--0HI/AAAAAAAAAwQ/-Umr3lVX9NwzyJo9tnuFeYKqMnTby4nEACLcBGAsYHQ/s320/smart-card-png.png">              
                        </div>
                        <div class="modal-footer justify-content-center text">                    
                           <button class="btn btn-primary btn-round" data-dismiss="modal" aria-hidden="true" type="button">Close</button>                           
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--Demo PIC -->   
			
			<div class="modal fade" id="idpic" tabindex="-1" role="" style="display: none;" aria-hidden="true">
               <div class="modal-dialog modal-login" role="document">
                  <div class="modal-content">
                     <div class="">
                        <div class="modal-header">
                           <div class="card-header card-header-primary text-center">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                              x
                              </button>
                              <h4 class="card-title">PNG Image Demo</h4>
                           </div>
                        </div>
                        <div class="modal-body"><center>				
                           <img  width="100px" height="125px" src="<?php echo $zorexid;?>/demo/png-pic.png"> </center>
<br><br>
✔<font color="red"> আপনার ছবিকে  মাথার উপর থেকে গলার নিচ পর্যন্ত Crop করুন, যেমনটা ছবিতে দেখালাম।</font><br>
✔<font color="green"> ছবির  Background টা Remove করে PNG format এ Save করে নিন।</font><br>
✔ কোন সমস্যা হলে পেইজে মেসেজ দিন: <a href="http://m.facebook.com/zorexz"><font color="blue">Zorex Zisa</font></a>
						   
                        </div>
                        <div class="modal-footer justify-content-center text">                    
                           <button class="btn btn-primary btn-round" data-dismiss="modal" aria-hidden="true" type="button">Close</button>                           
                        </div>
                     </div>
                  </div>
               </div>
            </div>
			
            <!--Demo End -->	
            <div class="card-body" style="text-align: left;">
               <?php
			   header('Content-Type: text/html; charset=utf-8');

                  /*
                  	Coded By zorex zisa
                  	Contact With Me - http://fb.com/zorexz
                  */
				  
//Delete				  
foreach (glob("picz/*") as $file1) {
	if (filemtime($file1)<time()-43200 && $file1!=="picz/view.php") { // older than 12hrs
		unlink($file1);
	}
}

foreach (glob("created/*") as $file2) {
	if (filemtime($file2)<time()-43200 && $file2!=="created/view.php") { // older than 12hrs
		unlink($file2);
	}
}
//Deleted	

                  $idno = rand(0,9).rand(0,9).rand(0,9).' '.rand(0,9).rand(0,9).rand(0,9).' '.rand(0,9).rand(0,9).rand(0,9).rand(0,9);

                  
                  if( isset($_POST['sub']))
                  {
                  $nbname = ipost("bname");
                  $ename = ipost("ename");
                  $nfname = ipost("fname");
                  $nmname = ipost("mname");
                  $dob = ipost("dob");
                  $blood = ipost("blood");
                  $sign = ipost("sign");
                  $naddress = ipost("address");
                  $idnox = ipost("idno");
				  
				  		//Names of File
		$znam = "png-smart-card-";
	    $num = $znam.date('is');
                  
                 
                			  				  
              /*    $fname = $num.".png";
                  if( move_uploaded_file($_FILES['pic']['tmp_name'], "picz/".$fname))
                  {
                  $ban = $fname;
                  }  */
                 
				 
 $error = array();
 
 //Image size
                  $max_size = 3*1024*1024;				  		  
                  if( $_FILES['pic']['size'] > $max_size )
                  {
                  $error[] = "Max Image size is 3MB";
                  }
				  
 //Image Extentions		  
				   $allowedExts = array("jpg", "jpeg", "gif", "png");
				   $extension = end(explode(".", $_FILES["pic"]["name"]));

    if ($_FILES["pic"]["type"] == "image/gif" || $_FILES["pic"]["type"] == "image/jpg" || $_FILES["pic"]["type"] == "image/jpeg" || $_FILES["pic"]["type"] == "image/png" && $_FILES["pic"]["size"] < 2500000 && in_array($extension, $allowedExts)) 
	
	{ $ftype = TRUE; }
                  
				  
				  
                  if( !@$ftype)
                  {
                  $error[] = "Your file is invalid ! Upload Only jpeg,png,gif,jpg images";
                  }
                  else
                  {				  				  
                  $fname = $num.".png";
                  if( move_uploaded_file($_FILES['pic']['tmp_name'], "picz/".$fname))
                  {
                  $ban = $fname;
                  }
                  }
                  if( !empty( $error))
                  {
                  foreach ($error as $err) 
                  {
                  echo "<div class='error'>$err</div>";
                  }

				  }
				  
             /*     if( !empty( $error))
                  {              
                  echo "<div class='error'>Please Upload JPG, PNG</div>";
                  }  */
				  
                  else
                  {
                  include "../includez/Unicode2Bijoy.class.php";
                  //
                  // Fonts
                  $banglab = "fonts/y.TTF";
                  $bangla = "fonts/x.TTF";
                  $english = "fonts/RobotoCondensed-Regular.ttf";
                  $englishbold = "fonts/RobotoCondensed-Bold.ttf";
                  $bold = "fonts/milf/milfb1.ttf";
                  $sign_f = "fonts/sign-3.ttf";
                  
                  $bname = Unicode2Bijoy::convert($nbname);
                  $fname = Unicode2Bijoy::convert($nfname);
                  $mname = Unicode2Bijoy::convert($nmname);
                  $address = Unicode2Bijoy::convert($naddress);
                  
                  //$idno = rand(0,9).rand(0,9).rand(0,9).' '.rand(0,9).rand(0,9).rand(0,9).' '.rand(0,9).rand(0,9).rand(0,9).rand(0,9);
                  $bg = $blood;
                  
                  $gimg="filez/png-bd/card.png";
                  $img=imagecreatefrompng($gimg);
				  
                  //Make it Transparent PNG
				  imagealphablending( $img, true );
                  imagesavealpha( $img, true );
                  
                  //Your Image
                  $imgSrc = "picz/".$ban;
				  				
			//IMG Creation
				if ($_FILES["pic"]["type"] == "image/png") 
				{$MyImg = imagecreatefrompng($imgSrc); }
				
				else {
				$MyImg = imagecreatefromjpeg($imgSrc); }
				
				
				list($myWidth, $myHeight) = getimagesize($imgSrc);   //xxxxxxx
			
			//Make Black and White			
                imagefilter($MyImg, IMG_FILTER_GRAYSCALE); //convert to grayscale
                  				
            //IMG Placing
                imagecopyresampled($img, $MyImg, 113, 280, 0, 0, 228, 285, $myWidth, $myHeight);  //xxxxxx
				  
				  

                  
                  $colorf=imagecolorallocate($img, 70, 68, 68);
                  $color=imagecolorallocate($img, 57, 61, 55);
                  $red = imagecolorallocate($img, 255, 0, 0);
                  
                  $black = imagecolorallocate($img, 65, 56, 61);
                  $black2 = imagecolorallocate($img, 31, 29, 34);
                  
                  imagefttext($img, 30, 0, 365, 327, $colorf, $banglab, $bname);
                  
				  $ename = strtoupper($ename);
                  imagefttext($img, 20, 0, 365, 394, $colorf, $englishbold, $ename);
                  
                  imagefttext($img, 30, 0, 365, 465, $colorf, $banglab, $fname);
                  
                  imagefttext($img, 30, 0, 365, 538, $colorf, $banglab, $mname);
                  
                  imagefttext($img, 25, 0, 495, 598, $black, $english, $dob);
                  
                  imagefttext($img, 30, 0, 493, 648, $black, $bold, $idnox);
                  
                  imagefttext($img, 30, 0, 170, 631, $black2, $sign_f, $sign);
                  
                  //weblink
                  $webc = imagecolorallocate($img, 70, 68, 68);
                  $webf = "fonts/nr.ttf";
                  $web = "www.Zorexid.cu.ma";
                 // imagefttext($img, 30, 0, 457, 53, $webc, $webf, $web);
                  
                  //little DoB
                  imagefttext($img, 15, 0, 832, 258, $colorf, $english, $dob);
				  
				  
                   //SEAL location
				$png = imagecreatefrompng('filez/png-bd/line.png');
				list($newwidth, $newheight) = getimagesize('filez/png-bd/line.png');   //xxxxxxx
                   //SEAL Placing
                  imagecopyresampled($img, $png, 79, 250, 0, 0, $newwidth, $newheight, $newwidth, $newheight);  //xxxxxx
				  
                  //face location
                 $pngf = imagecreatefrompng('filez/png-bd/box.png');
                 list($newwidthf, $newheightf) = getimagesize('filez/png-bd/box.png');   //yyyyyy
                  
                  //face Placing
                  imagecopyresampled($img, $pngf, 96, 262, 0, 0, $newwidthf, $newheightf, $newwidthf, $newheightf);  //yyyyyy
                  
                 
                  
                  
                  //header("Content-Type:image/png");				  
                  $f = "created/".$num.".png";
                  imagepng($img, $f);
                  imagedestroy($img);
                  echo '<div class="icontent">
                  				<p>Your Card is Ready ! Please Download It From Below</p>
                  				<a href="'.$f.'"><img width="100%" src="'.$f.'" alt="zorex-nid" class="nid_pre" /></a>
                  				<a href="'.$f.'" download="smart-card-png-zorexid.png"><center><br><button class="btn btn-primary pull-right text">Download</button></center></a>
                  			</div>';
                  
                  
                  }
                  }
                  
                  else
                  {
                  
                  ?>	
               <center><font color="red">এটি শুধুমাত্র  জরুরী দরকারে Social Media Verification এর  জন্য তৈরি। <br>ভুয়া জাতীয় পরিচয়পত্র ব্যাবহার দন্ডনীয় আপরাধ</font></center><br>
               <form action="" method="post" enctype="multipart/form-data">
                  <div class="row">
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Own name <font color="red">(in Bangla)</font></label>
                           <input name="bname" placeholder="নিজের নাম বাংলায় লিখুন " type="text" class="form-control">
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Own name <font color="red">(in English)</font></label>
                           <input  name="ename" placeholder="নিজের নাম ইংরেজিতে লিখুন" type="text" class="form-control">
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Father's name <font color="red">(Bangla)</font></label>
                           <input name="fname" placeholder="পিতার নাম বাংলায় লিখুন" type="text" class="form-control">
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Mother's name <font color="red">(Bangla)</font></label>
                           <input name="mname" placeholder="মায়ের নাম বাংলায় লিখুন" type="text" class="form-control">
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Date Of Birth <font color="red">(English)</font></label>
                           <input name="dob" placeholder="5 Jan 1998" type="text" class="form-control">
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Signature <font color="red">(in English)</font></label>
                           <input name="sign"  placeholder="ইংরেজিতে ডাকনাম লিখুন" type="text" class="form-control">
                        </div>
                     </div>
                  </div>
				  <div class="col-md-12">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Smart Card Number <font color="red">(Optional)</font> </label>
                           <input name="idno"  value="<?php echo $idno;?>" type="text" class="form-control">
                        </div>
                     </div>
                  <div class="row">
                     <div class="col-md-12">
                        <div class="form-group bmd-form-group">
                           <label class="bmd-label-floating">Your Image 
<a data-toggle="modal" data-target="#idpic"><font color="blue"> [Demo]</font><div class="ripple-container"></div></a>
						   </label>
                           <input type="file" name="pic" required="required"/>
                        </div>
                     </div>
                  </div>
                  <input type="checkbox" name="checkbox" value="check" id="agree" required="required" /> I have read and agree to the <a data-toggle="modal" data-target="#terms" style="color: #1861bf;">Terms and Conditions</a>.<br><br> 
                  <?php include "../includez/terms.php";?>
                  <div class="g-ytsubscribe" data-channelid="UCL9pcMV_mgXNBNSKpBql8Fw" data-layout="default" data-count="hidden"></div>
                  <div class="fb-like" data-href="https://www.facebook.com/zorexz" data-width="" data-layout="button" data-action="like" data-size="large" data-share="false"></div>
                  <button type="submit" name="sub" class="btn btn-primary pull-right">Create</button>
               </form>
               <?php } ?>
            </div>
         </div>
         <!-- Advertise Bottom-->
         <?php include "../includez/ad-bottom.php";?>
         <!-- Advertise Bottom end-->
         <!-- Profile of Zorex --> 
         <?php include "../includez/profile.php";?>		  
         <!-- Profile of Zorex -->   
      </div>
   </div>
   <!-- Advertise Side-->
   <?php include "../includez/ad-side.php";?>
</div>
</div>
</div>
<?php  include "../includez/footer.php";?>
