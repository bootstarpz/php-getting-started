<?php $title = "Fake id Card Maker - Make Fake ID Card Online";?>
<?php include "includez/header.php";?>

<!-- Section start -->
	<section class="main">
		<div class="container_fluid">		  
		<div class="row"> 
		    	<div class="col-md-12">
		    		<div class="alert alert-info">
					
		    			<p style="text-align:center"><font color="red"><b>ZorexID is for creating an Id Card Only for your Emergency Need,  No need to login or register and it's free For All</b></font></p>
						
		    		</div>
	<div class="row">
		    			<div class="col-md-6">
				    		<div class="box wow" style="color: red;" data-wow-delay="0.3s" style="visibility: visible; -webkit-animation-delay: 0.3s; -moz-animation-delay: 0.3s; animation-delay: 0.3s;">
				    			<div class="box-header">About ID Cards</div>
				    			<div class="box-content" style="padding:0px;">
				    				<div class="ilist">
				    					<ul class="about"><li><i class="no no-link"></i>These ID Cards are legal offense used for any personal use</li>
					    					<li><i class="no no-link"></i>These are for facebook verification and entertainment purpose only</li>
					    					<li><i class="no no-link"></i>We are not responsible for any problem or problem that is used in any personal work</li>
					    				</ul>
				    				
				    				</div>
				    			</div>
				    		</div>
							
							<div class="box wow" data-wow-delay="0.3s" style="visibility: visible; -webkit-animation-delay: 0.3s; -moz-animation-delay: 0.3s; animation-delay: 0.3s;">
				    			<div class="box-header">Site Info</div>
				    			<div class="box-content" style="padding:0px;">
				    				<div class="ilist">
				    					<ul class="about"><li><i class="fa info"></i><a href="https://facebook.com/groups/zorexzone"><img style="width: 200px;"src="<?php echo $zorexid;?>/stylez/btn/1.png"></a>
										</li>
<li style=><i class="fa info"></i><font color="#009600"> <div class="g-ytsubscribe" data-channelid="UCL9pcMV_mgXNBNSKpBql8Fw" data-layout="default" data-count="default"></div></font></li>
<li><i class="fa info"></i><div class="fb-like" data-href="https://www.facebook.com/zorexz" data-width="" data-layout="button_count" data-action="like" data-size="small" data-share="true"></div></li>
											

					    				</ul>
				    				
				    				</div>
				    			</div>
				    		</div>
							
				    	</div>
						
		    			<div class="col-md-6">
				    		<div class="box wow" data-wow-delay="0.3s" style="visibility: visible; -webkit-animation-delay: 0.3s; -moz-animation-delay: 0.3s; animation-delay: 0.3s;">
				    			<div class="box-header">Make ID Cards</div>
				    			<div class="box-content" style="padding:0px;">
				    				<div class="ilist">
				    					<ul><li><i class="fa id"></i><a href="<?php echo $zorexid;?>/id/nid-front"> Old Nid Card Front</a></li>
										<li><i class="fa id"></i> <a href="<?php echo $zorexid;?>/id/nid-full"> Old Nid Card Full</a></li>
										<li><i class="fa id"></i><a href="<?php echo $zorexid;?>/id/driving-license"> Driving License</a></li>
										<li><i class="fa id"></i> <a href="<?php echo $zorexid;?>/id/autistic-card"> Autistic ID Card</a></li>
					    				<li><i class="fa id"></i><a href="<?php echo $zorexid;?>/id/smart-card"> Smart Card (Front) </a></li>
					    				<li><i class="fa id"></i><a href="<?php echo $zorexid;?>/id/smart-back"> Smart Card (Back)  </a></li>
					    				<li><i class="fa id"></i><a href="<?php echo $zorexid;?>/id/smart-card-png"> Smart Card (PNG) <i class="fa new"></i></a></li>
					    				<li><i class="fa id"></i><a href="<?php echo $zorexid;?>/id/smart-hold"> Smart Card (Holding)</a></li>
					    				<li><i class="fa id"></i><a href="<?php echo $zorexid;?>/id/fbid"> Facebook ID Card </a></li>
										<li><i class="fa id"></i><a href="<?php echo $zorexid;?>/p?request">Request For Custom ID Card</a></li>
										

											</ul>
				    				</div>
				    			</div>
				    		</div>
				    	</div>
						
				    </div>
					
					<div class="col-md-6">
				    		<div class="box wow" data-wow-delay="0.3s" style="visibility: visible; -webkit-animation-delay: 0.3s; -moz-animation-delay: 0.3s; animation-delay: 0.3s;">
				    			<div class="box-header">Other Tools</div>
				    			<div class="box-content" style="padding:0px;">
				    				<div class="ilist">
				    					<ul><li><i class="fa ot"></i><a href="http://zorexid.cu.ma/corona-live-update">Corona Virus Live Update</a><i class="fa new"></i></li>
										<!--
				    					<li><i class="fa ot"></i><a target="_blank" href="http://zoogle.cf/make">Search Engine Maker</a></li>
										<li> <i class="fa ot"></i> <a target="_blank" href="http://zoogle.cf/image-search">Search With Image</a></li>
										<li><i class="fa ot"></i><a target="_blank" href="http://zoogle.cf/web-translator">Webpage Translator</a></li> -->
										
										<li><i class="fa ot"></i><a target="_blank" href="http://zorexlogo.ml">Logo Maker</a></li>
											</ul>
				    				</div>
				    			</div>
				    		</div>
				    	</div>
					
					
			<!--		<div class="row">
					<div class="col-md-6">
				    	<div class="box wow" data-wow-delay="0.3s" style="visibility: visible; -webkit-animation-delay: 0.3s; -moz-animation-delay: 0.3s; animation-delay: 0.3s;">
				    		<div class="box-header">Youtube Tools</div>
				    			<div class="box-content" style="padding:0px;">
				    				<div class="ilist">
				    					<ul>
					    				<li><i class="fa fb"></i><a href="<?php echo $zorexid;?>/p?wait"> Birthday Whisher <i class="fa new"></i></a></li>
					    				<li><i class="fa fb"></i><a href="<?php echo $zorexid;?>/p?wait"> Facebook Tools</a></li>
										<li><i class="fa fb"></i><a href="<?php echo $zorexid;?>/p?wait"> 18+ Viewer</a></li>


										</ul>
				    				</div>
				    			</div>
				    		</div>
				    	</div>
				    </div>  -->
					
					
					</div>

					
					
					
		    	</div>
		    </div>

		</section></div>
	
	<!-- ../Section End -->




<?php include "includez/footer.php";?>
