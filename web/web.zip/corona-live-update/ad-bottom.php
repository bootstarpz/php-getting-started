<div class="card card-profile ">
                <div class="card-body">
                  <h6 class="card-category text-gray">Advertise</h6>
                  <p class="card-description">
                    Subscribe to our youtube channel and Support us with your donation
					</p>
					
					<style>
					.don {
                display: flex; }
@media only screen and (max-width: 385px) {	
	.don {
   display: block;
}
</style>
					
					
					
					<div class="don">
					<div class="g-ytsubscribe" data-channelid="UCL9pcMV_mgXNBNSKpBql8Fw" data-layout="full" data-count="default"></div>
					
					<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick" />
<input type="hidden" name="hosted_button_id" value="MFTUMP6BTEU76" />
<input type="image" src="https://3.bp.blogspot.com/--cimkkfY3cA/Xet3Y_gu3QI/AAAAAAAAAk4/s9nyNSz5HCMnKHsAiaCdt66qtNiuMR63gCLcBGAsYHQ/s1600/donate.png" border="0" name="submit" title="PayPal - The safer, easier way to pay online!" alt="Donate with PayPal button" width="130px" />
<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1" />
</form>
                 
				 
                </div>
                </div>
              </div>					
			   <?php include "comment.php";?>

			

			
			</div>            
			<div class="col-md-4">