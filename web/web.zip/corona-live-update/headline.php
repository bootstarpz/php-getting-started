<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<style>
   @import "https://fonts.maateen.me/adorsho-lipi/font.css";
   body {
   background: #fff;
   font-family:'AdorshoLipi';
   }
   .stat-box{
   background: #f8f8f8;
   border-bottom: 2px solid #0281b0;
   border-top: 2px solid #0281b0;
   color: #000;
   }
   .stat-box a.source {
   color: #000;
   font-size: 14px;
   display: inline-block;
   margin-top: 10px;
   }
   .stat-box h4{
   padding: 0 0 15px;
   text-align: center;
   border-bottom: 3px double;
   margin-bottom: 0;
   font-size: 24px;
   font-weight: bold;
   }
   .table-responsive{
   display:block;
   overflow:auto;
   max-height:248px;
   border: 1px solid #eee;
   }
   .table>thead:first-child>tr:first-child>th {
   position: sticky;
   top: 0;
   background: #e7e7e7;
   }
   .table a{
   color: #337ab7;
   }
   .no {display:none!important;}
   .media-left span { color:#087614;}
   .media-body, .media-left {
   border-top: 1px solid #e5e5e5;
   padding-top: 13px;
   }
   .media-body{
   padding-left: 10px;
   }
   h3 {background:
   #e5ffd9;
   padding: 10px;
   margin: 0;
   border-bottom: 2px solid
   green;}	
</style>
<?php
   require_once('htmldom.php');
   
   // Create DOM from URL or file
   $html = file_get_html('https://www.jagonews24.com/topic/%E0%A6%95%E0%A6%B0%E0%A7%8B%E0%A6%A8%E0%A6%BE%E0%A6%AD%E0%A6%BE%E0%A6%87%E0%A6%B0%E0%A6%BE%E0%A6%B8');
   
   // Find all images
   foreach($html->find('div[class=neday]') as $element)
   $html->find('a[class=btn btn-default btn-lg btn-block]', 0)->class = 'no';
          echo $element;
   	   ?>
