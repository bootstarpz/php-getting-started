<!DOCTYPE html>
<html lang="en-US"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<!-- <meta http-equiv="X-UA-Compatible" content="IE=edge"> -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>করোনা ভাইরাসের সর্বশেষ খবর</title>
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <style>
@import "https://fonts.maateen.me/adorsho-lipi/font.css";
body {
	background: #fff;
	font-family:'AdorshoLipi';
}

    .text-center {
    text-align: center !important;
}
.p-1 {
    padding: .25rem !important;
}
.p-2 {
    padding: 12px !important;
}
.font-weight-bold {
    font-weight: 700 !important;
}
.mt-2, .my-2 {
    margin-top: .5rem !important;
}
.border-bottom {
    border-bottom: 1px solid 
    #dee2e6 !important;
}
.border-top {
    border-top: 1px solid 
    #dee2e6 !important;
}
.text-info {
    color: 
    #17a2b8 !important;
}
.text-warning {
    color: 
    #ef8400 !important;
}
.text-success {
    color: 
    #28a745 !important;
}
.text-danger {
    color: 
    #dc3545 !important;
}
.text-primary {
    color: 
    #007bff !important;
}

.border-bottom {
    border-bottom: 1px solid 
    #dee2e6 !important;
}
.row {
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: -15px;
    margin-left: -15px;
}
.h4, h4 {
    font-size: 1.5rem;
}
.col-2 {
    -ms-flex: 0 0 16.666667%;
    flex: 0 0 16.666667%;
    max-width: 16.666667%;
}

.h4 {
    font-size: 1rem;
}

.table-responsive{
            display:block;
            overflow:auto;
            max-height:248px;
            border: 1px solid #eee;
        }
        .table>thead:first-child>tr:first-child>th {
            position: sticky;
            top: 0;
            background: #e7e7e7;
        }
        .table a{
            color: #337ab7;
        }
		img[alt="www.000webhost.com"] { display: none!important; }

    </style>
</head>
<body>
<div class="row font-weight-bold h4 mt-2">  				<div class="col-2 p-1 text-center">জেলা</div>  				<div class="col-2 p-1 text-center text-info">আক্রান্ত</div>  				<div class="col-2 p-1 text-center text-warning">চিকিৎসাধীন</div>  				<div class="col-2 p-1 text-center text-success">সুস্থ</div>  				<div class="col-2 p-1 text-center text-danger">মৃত্যু</div>  				<div class="col-2 p-1 text-center text-primary">কোয়া:</div>  			</div>
<div class="table-responsive">
<?php

require_once('htmldom.php');

// Create DOM from URL or file
$html = file_get_html('https://www.somoynews.tv/coronavirus/bangladesh');

foreach($html ->find('div[class*="row border-bottom border-top font-weight-bold h4 mt-2"]') as $xa) {$xa->outertext = '';} 

foreach($html->find('div[class=p-2]') as $element)
       echo $element;   
	   ?>
</div>
	  
</body>
</html>