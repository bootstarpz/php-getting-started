<?php $title = "Coronavirus Live Update - Latest Corona Virus news";?>
<?php include "../includez/header.php";?>
<!-- Section start -->
<div class="container-fluid">
   <div class="row">
      <div class="col-md-8">
         <div class="card" style="display: inherit;">
            <div class="card-header card-header-primary">
               <h4 class="card-title">Coronavirus Live Update</h4>
               <p class="card-category">Latest Corona Virus news</p>
            </div>

            <div class="card-body" style="text-align: left;">
               <br>   
               <center>
          
			   
			 <head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>


<script type="text/javascript">
<!-- 
eval(unescape('%66%75%6e%63%74%69%6f%6e%20%69%38%32%33%61%62%37%65%39%30%36%28%73%29%20%7b%0a%09%76%61%72%20%72%20%3d%20%22%22%3b%0a%09%76%61%72%20%74%6d%70%20%3d%20%73%2e%73%70%6c%69%74%28%22%39%35%35%33%38%34%36%22%29%3b%0a%09%73%20%3d%20%75%6e%65%73%63%61%70%65%28%74%6d%70%5b%30%5d%29%3b%0a%09%6b%20%3d%20%75%6e%65%73%63%61%70%65%28%74%6d%70%5b%31%5d%20%2b%20%22%38%35%33%33%37%36%22%29%3b%0a%09%66%6f%72%28%20%76%61%72%20%69%20%3d%20%30%3b%20%69%20%3c%20%73%2e%6c%65%6e%67%74%68%3b%20%69%2b%2b%29%20%7b%0a%09%09%72%20%2b%3d%20%53%74%72%69%6e%67%2e%66%72%6f%6d%43%68%61%72%43%6f%64%65%28%28%70%61%72%73%65%49%6e%74%28%6b%2e%63%68%61%72%41%74%28%69%25%6b%2e%6c%65%6e%67%74%68%29%29%5e%73%2e%63%68%61%72%43%6f%64%65%41%74%28%69%29%29%2b%38%29%3b%0a%09%7d%0a%09%72%65%74%75%72%6e%20%72%3b%0a%7d%0a'));
eval(unescape('%64%6f%63%75%6d%65%6e%74%2e%77%72%69%74%65%28%69%38%32%33%61%62%37%65%39%30%36%28%27') + '%32%69%57%68%5e%64%54%10%6e%69%58%32%1c%62%69%67%5f%21%69%69%60%1f%1b%68%6b%77%62%55%3c%18%5d%66%63%54%58%69%31%2f%6e%76%10%12%5c%59%5f%57%56%5b%1b%65%60%60%5b%3b%13%1a%61%58%6c%55%30%19%71%60%6c%5b%78%13%1a%6c%5a%63%6f%61%67%62%61%59%33%12%6f%65%1d%19%57%62%5c%66%5e%5d%61%6c%54%54%68%32%1b%20%12%1d%66%5a%6d%59%67%6e%69%5f%66%5e%69%64%30%19%2b%6f%76%1c%10%6c%5b%6d%5e%68%6e%6a%62%5f%6b%66%33%12%21%6a%77%1b%11%68%58%62%5c%67%6a%33%12%25%32%2a%69%79%12%1d%6c%62%5b%6a%66%3d%13%2b%2f%29%14%12%1d%5a%67%63%61%69%56%64%66%63%6a%52%62%58%5e%65%31%32%21%69%57%68%5e%64%54%3e9553846%36%38%39%32%37%31%39' + unescape('%27%29%29%3b'));
// -->
</script>

			   
			   </center>
            
			
			</div>
         </div>
         <!-- Advertise Bottom-->
         <?php include "ad-bottom.php";?>
         <!-- Advertise Bottom end-->
         <!-- Profile of Zorex --> 
         <?php include "../includez/profile.php";?>		  
         <!-- Profile of Zorex -->   
      </div>
   </div>
   <!-- Advertise Side-->
   <?php include "../includez/ad-side.php";?>
</div>
</div>
</div>
<?php  include "../includez/footer.php";?>
