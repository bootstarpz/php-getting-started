<!DOCTYPE html>
<html lang="en-US"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<!-- <meta http-equiv="X-UA-Compatible" content="IE=edge"> -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>করোনা ভাইরাসের সর্বশেষ খবর</title>
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<style>
@import "https://fonts.maateen.me/adorsho-lipi/font.css";
body {
	background: #fff;
	font-family:'AdorshoLipi';
}
#haff {background: #f10c0c!important;}
#hrec {background: #3ab530!important;}
        .stat-box{
           /* background: #f8f8f8;
            border-bottom: 2px solid #0281b0; 
            border-top: 2px solid #0281b0; */
            color: #000;
        }
        .stat-box a.source {
            color: #000;
            font-size: 14px;
            display: inline-block;
            margin-top: 10px;
        }
        .stat-box h4{
            padding: 0 0 15px;
            text-align: center;
            border-bottom: 3px double;
            margin-bottom: 0;
            font-size: 24px;
            font-weight: bold;
        }
        .table-responsive{
            display:block;
            overflow:auto;
            max-height:248px;
            border: 1px solid #eee;
        }
        .table>thead:first-child>tr:first-child>th {
            position: sticky;
            top: 0;
            background: #e7e7e7;
        }
        .table a{
            color: #337ab7;
        }
img[alt="www.000webhost.com"] { display: none!important; }

    </style>
</head>
<body>

<?php

require_once('htmldom.php');

// Create DOM from URL or file
$html = file_get_html('https://www.jagonews24.com/topic/%E0%A6%95%E0%A6%B0%E0%A7%8B%E0%A6%A8%E0%A6%BE%E0%A6%AD%E0%A6%BE%E0%A6%87%E0%A6%B0%E0%A6%BE%E0%A6%B8');

// Find all images
foreach($html->find('div[class=paddingBottom20]') as $element)
$html->find('h4', 0)->innertext = '<img width="70px"src="https://media.giphy.com/media/2A2DRLcRSCWtvNBv1f/giphy.gif"><a href="http://zorexid.cu.ma">করোনা ভাইরাস - লাইভ আপডেট </a>';
$html->find('a[class=source small marginTop10]', 0)->innertext = '';
       echo $element;   
	   ?>
	   <a style="color:black" target="_blank" rel="nofollow" href="https://multimedia.scmp.com/infographics/news/china/article/3047038/wuhan-virus/index.html?src=article-launcher" class="source small marginTop10"> তথ্যসূত্র: চীনের জাতীয় স্বাস্থ্য কমিশন (সিএনএইচসি) ও অন্যান্য।</a>
	   <br>
	    ডিজাইন ও ডেভেলপমেন্ট:<a target="_blank" style="color:#1b5cb0;font-size: 17px;font-family: arial;" href="https://facebook.com/zorexz" class="source small marginTop10"> Zorex Zisa</a>
</body>
</html>