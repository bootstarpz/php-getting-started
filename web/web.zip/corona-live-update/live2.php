<!DOCTYPE html>
<html lang="en-US"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<!-- <meta http-equiv="X-UA-Compatible" content="IE=edge"> -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>করোনা ভাইরাসের সর্বশেষ খবর</title>


<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<style>
   @import "https://fonts.maateen.me/adorsho-lipi/font.css";
   body {
   background: #000;
   font-family:'AdorshoLipi';
   }
.wrap {
    width: auto;
    background: #000;
    overflow: hidden;
    position: relative;
    border-radius: 10px;
}

.wrap .list {

    list-style: none;
    margin: 10px;
        margin-left: 10px;
    padding: 0;
    width: 200px;
}

.wrap .corona-col.clogo {

    border-right: 1px solid #4c4c4c;
    background-image: url(https://s3-ap-southeast-1.amazonaws.com/cdn.jagonews24.com/media/common/virus-logo.png);
    background-position: top left;
    background-repeat: no-repeat;
    background-size: 150px;

}.wrap .corona-col {

    flex: 0 0 50%;
    max-width: 50%;

}.wrap .corona-col.clogo .virus-logo {

    display: flex;
    flex-direction: column;
    width: 100%;
    justify-content: center;
    align-items: center;
    text-align: center;
    color: #fff;

}.wrap .corona-col.clogo .virus-logo h2 {

    font-size: 3rem;
    font-weight: 700;

}.wrap .corona-col.clogo .virus-logo h2 small {

    color: #fff;

}.wrap .corona-col {

    flex: 0 0 50%;
    max-width: 50%;

}.wrap .corona-col .height-100 {

    display: flex;
    flex-direction: column;
    justify-content: center;

}.total-cases, .recovered-cases, .death-cases {

    display: flex;
    flex-direction: column;
    align-items: center;
    flex-grow: 1;

}.total-cases h1 {

    color: #e3b410;

} .total-cases, .recovered-cases, .death-cases {

    display: flex;
    flex-direction: column;
    align-items: center;
    flex-grow: 1;

}.wrap .cases-count .recovered-cases h1 {

    color: #25ad00;
	padding-left: 20px;

}
.wrap .cases-count .death-cases h1 {

    color: #d51e20;
	padding-left: 20px;

}
.wrap .cases-count h1 {

    font-size: 3rem;
    line-height: 66px;
    margin-top: 0;
    margin-bottom: 0;

}
.wrap .cases-count h5 {

    font-size: 18px;
    line-height: normal;
    margin: 0;
    color: #fff;
    text-transform: uppercase;
    font-weight: 500;

}.wrap .cases-count {

    display: flex;
    padding: 30px;

}

.wrap .list {

    list-style: none;
 /*   display: flex; */
    margin: 10px;
        margin-left: 10px;
    padding: 0;


}
.wrap .list__item {

    flex-grow: 0;
    flex-shrink: 0;
    background: rgba(34,34,34,.5);
    border: 1px solid #565656 !important;
    margin: 0 7px;
    border-radius: 7px;
    padding: 3px 15px !important;

}
.wrap span.name {

    text-align: center;
    color: #fff;
    font-size: 17px;
    margin-right: 12px;
    text-transform: uppercase;
    margin-bottom: 0;

}
.wrap span.number {

    text-align: center;
    color: #e3b410;
    font-size: 21px;
    margin-bottom: 0;
    font-weight: 600;

}
strong {

    font-weight: 700;

}
.wrap .sourcing {

    color: #fff;
    padding: 5px;
    font-size: 13px;
    background: #272727;

}
.text-center {

    text-align: center;

}
  @media only screen and (max-width: 600px) {
.wrap .cases-count {
margin-left: -50px; }
.columns{ margin-left: -50px; margin-top: -13px;margin-bottom: -20px; }

  .wrap .corona-col.clogo { background-image:none;} }
.corona-col.clogo { display:none;} }
img[alt="www.000webhost.com"] { display: none!important; }

</style>


<center>
<?php
   require_once('htmldom.php');
   
   // Create DOM from URL or file
   $html = file_get_html('https://www.jagonews24.com/topic/%E0%A6%95%E0%A6%B0%E0%A7%8B%E0%A6%A8%E0%A6%BE%E0%A6%AD%E0%A6%BE%E0%A6%87%E0%A6%B0%E0%A6%BE%E0%A6%B8');
   
   // Find all images
   foreach($html->find('div[id=containerElem]') as $element)
   $html->find('a[class=btn btn-default btn-lg btn-block]', 0)->class = 'no';
          echo $element;
   	   ?>
	   
</center>
	   
	   
	   
	   
	   
	   
