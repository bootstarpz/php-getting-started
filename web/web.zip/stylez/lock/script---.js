var btnafter = $(".btn_after");
var btnbefore = $(".btn_before");
var subscribe = $("#sociallocker");

subscribe.css("display", "none");
btnafter.css("display", "none");
btnbefore.click(function(){
  subscribe.css("display", "block");
  $(this).css("display","none");
});
$('.subscribe-text').click(function(){
popitup();
});
function popitup() {       
newwindow = window.open('https://www.youtube.com/channel/UCL9pcMV_mgXNBNSKpBql8Fw?sub_confirmation=1', 'Share Link', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600,top=' + (screen.height/2 - 300) + ',left=' + (screen.width/2 - 300));
 var timer = setInterval(function() { 
    if(newwindow.closed) {
        clearInterval(timer);
        alert('Thank\'s for your subscription i think you might like my videos.');
      document.querySelector("#sociallocker-links").style.display = "none";
		                    document.querySelector("#sociallocker-overlay").style.display = "none"; 
		                    document.querySelector("#sociallocker-content").style.top = "0";
    }
}, 1000);
}
$(document).ready(function() {
$(".row").each(function() {
var currentRow = $(this);
var scUserID = $(this).attr("data-sc");
var ytUserID = $(this).attr("data-yt");
var apiKey = 'AIzaSyAyWsBUsAChiYPDOptU-NBAh_p7oExR1oc';
var youtubeLink = 'https://www.googleapis.com/youtube/v3/channels?part=statistics&id='+ytUserID+'&key='+apiKey;
$.get(youtubeLink, function (data) {
$.each(data.items, function (i, item) {
var subCount = '' + Number(item.statistics.subscriberCount) + '';
$(currentRow).find(".yt-count").attr("data-count", roundNum(subCount));
});
})
});
});
// ROUND NUMBERS
function roundNum(num) {
var parts = num.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,").split(",");
return parts.length > 1 ? (Math.round(parseInt(parts.join(""), 10) / Math.pow(1000, parts.length-1)) + ["K", "M", "B"][parts.length-2]) : parts[0];
}
var subButton = document.querySelector('.subscribe-button');
var subbedClass = 'subbed';
subButton.addEventListener('click', function(e) {
toggleSubbed();
e.preventDefault();
});
function toggleSubbed() {
var text;
var count = subButton.dataset.count;
console.log(count)
if (subButton.classList.contains(subbedClass)) {
subButton.classList.remove(subbedClass);
text = 'Subscribe';
count--;
} else {
subButton.classList.add(subbedClass);
text = 'Subscribed';
count++;
}
subButton.querySelector('.subscribe-text').innerHTML = text;
subButton.dataset.count = count;
}
if ('alert' == '') {
window.setInterval(toggleSubbed, 1000);
}