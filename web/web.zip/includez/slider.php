<!--
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
-->	  
      <link rel="stylesheet" href="slider_files/style.css" type="text/css">
      <script type="text/javascript" src="slider_files/jquery_009.js"></script>
      <script type="text/javascript" src="slider_files/jquery_008.js"></script>
      <script type="text/javascript" src="slider_files/jquery_010.js"></script>

	 <div class="containersd clearfix">
        
         <div id="slider">
            <div class="flexslider">
               <div class="flex-viewport" style="overflow: hidden; position: relative;">
                  
               </div>
               <ul class="flex-direction-nav">
                  <li><a class="flex-prev" href="#">Previous</a></li>
                  <li><a class="flex-next" href="#">Next</a></li>
               </ul>
            <div class="flex-viewport" style="overflow: hidden; position: relative;"><div class="slider-wrap" style="width: 2000%; margin-left: -6010.78px;"><div class="slide clone" style="width: 768px; float: left; display: block;">
                        <a href="https://www.omicronlab.com/avro-keyboard.html"><img src="slider_files/avro-keyboard.jpg" title="Avro Keyboard for Windows"></a>
                     </div>
                     <div class="slide clone" style="width: 768px; float: left; display: block;">
                        <a href="https://www.omicronlab.com/bangla-fonts.html"><img src="slider_files/bangla-fonts.jpg" title="Free Bangla Fonts"></a>
                     </div>
                     <div class="slide" style="width: 768px; float: left; display: block;">
                        <a href="https://www.omicronlab.com/avro-keyboard.html"><img src="slider_files/avro-keyboard.jpg" title="Avro Keyboard for Windows"></a>
                     </div>
                     <div class="slide" style="width: 768px; float: left; display: block;">
                        <a href="https://www.omicronlab.com/portable-avro-keyboard.html"><img src="slider_files/avro-keyboard-portable.jpg" title="Avro Keyboard Portable Edition"></a>
                     </div>
                     <div class="slide" style="width: 768px; float: left; display: block;">
                        <a href="https://www.omicronlab.com/iavro.html"><img src="slider_files/iavro.jpg" title="iAvro for Mac OS X"></a>
                     </div>
                     <div class="slide" style="width: 768px; float: left; display: block;">
                        <a target="_blank" href="http://linux.omicronlab.com/"><img src="slider_files/ibus-avro-ubuntu.jpg" title="ibus-avro for Linux"></a>
                     </div>
                     <div class="slide" style="width: 768px; float: left; display: block;">
                        <a target="_blank" href="https://chrome.google.com/webstore/detail/pmilhebmfgmdinpmiedeibopblofaogk"><img src="slider_files/avro-chrome.jpg" title="Avro Phonetic for Google Chrome Browser"></a>
                     </div>
                     <div class="slide" style="width: 768px; float: left; display: block;">
                        <a href="https://www.omicronlab.com/bangla-fonts.html"><img src="slider_files/bangla-fonts.jpg" title="Free Bangla Fonts"></a>
                     </div>
                     <div class="slide clone flex-active-slide" style="width: 768px; float: left; display: block;">
                        <a href="https://www.omicronlab.com/avro-keyboard.html"><img src="slider_files/avro-keyboard.jpg" title="Avro Keyboard for Windows"></a>
                     </div>
                  <div class="slide clone" style="width: 768px; float: left; display: block;">
                        <a href="https://www.omicronlab.com/bangla-fonts.html"><img src="slider_files/bangla-fonts.jpg" title="Free Bangla Fonts"></a>
                     </div></div></div><ul class="flex-direction-nav"><li><a class="flex-prev" href="#">Previous</a></li><li><a class="flex-next" href="#">Next</a></li></ul></div>
            <div class="slider-border"></div>
         </div>
         <script type="text/javascript">
            $(window).load(function() {
                $(".flexslider").flexslider({
                    selector: ".slider-wrap > .slide",
                    animation: "slide",
                    easing: "easeOutExpo",
                    direction: "horizontal",
                    slideshowSpeed: 3000,
                    animationSpeed: 550,
                    pauseOnAction: true,
                    pauseOnHover: true,
                    useCSS: true,
                    touch: true,
                    video: true,
                    controlNav: false,
                    directionNav: true,
                    keyboard: true
                });
            });
            
         </script>
      </div>
