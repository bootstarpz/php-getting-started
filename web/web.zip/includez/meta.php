<head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
   <meta property="fb:pages" content="341771083197507" />
   
   <link rel="apple-touch-icon" sizes="180x180" href="<?php echo $zorexid;?>/favicons/apple-touch-icon.png">
   <link rel="icon" type="image/png" sizes="32x32" href="<?php echo $zorexid;?>/favicons/favicon-32x32.png">
   <link rel="icon" type="image/png" sizes="16x16" href="<?php echo $zorexid;?>/favicons/favicon-16x16.png">
   <link rel="manifest" href="<?php echo $zorexid;?>/favicons/site.webmanifest">
   <link rel="mask-icon" href="<?php echo $zorexid;?>/favicons/safari-pinned-tab.svg" color="#ff6c00">
   <meta name="msapplication-TileColor" content="#ffffff">
   <meta name="theme-color" content="#ffffff">
   
   <link rel="alternate" type="application/rss+xml" title="Latest Shows on Crunchyroll" href="http://feeds.feedburner.com/crunchyroll/rss" />
   <link rel="alternate" type="application/rss+xml" title="Latest Anime News" href="http://feeds.feedburner.com/crunchyroll/animenews" />
   <link rel="canonical" href="<?php echo $zorexid;?>" />
   
   <link href="https://plus.google.com/106460836780899737568" rel="publisher" />
   <meta property="og:url" content="<?php echo $zorexid;?>" />
   <meta property="og:site_name" content="ZorexID" />
   <meta property="og:type" content="online-tools" />
   <meta name="og:description" content="Make fake national id card online &amp; fake id generator Online"/>
   
   
   <meta name="description" content="OmicronLab Official Site" />
	<meta name="keywords" content="OmicronLab, Bangla Computing, Bengali Computing, Avro, Avro Keyboard, Phonetic, Software, Fonts" />
	<meta name="robots" content="index, follow" />

    

  <meta property="og:image" content="https://www.omicronlab.com/assets/images/og/avro.jpg" />
  <meta property="og:image:type" content="image/jpeg">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="627">

  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:site" content="@omicronlab">
  <meta name="twitter:creator" content="@omicronlab">
  <meta name="twitter:domain" content="omicronlab.com">
  <meta name="twitter:title" content="Welcome to OmicronLab!">
  <meta name="twitter:description" content="OmicronLab Official Site">
  <meta name="twitter:image:src" content="https://www.omicronlab.com/assets/images/og/avro.jpg">
   
   
   
   
   
   
   
   <title>Zorex ID - Fake id card maker Online</title>
  

   <meta name="y_key" content="82335d8b0386de0f"/>
   <meta name="title" content="Crunchyroll - Watch Popular Anime & Read Manga Online" />
   
   <meta name="description" content="Watch the best anime online and legally stream simulcasts including Dragon Ball Super, Attack on Titan, Naruto Shippuden, My Hero Academia, One Piece, and more."/>
  
   
   <!-- End Facebook Pixel Code -->
   <meta name="google-site-verification" content="zuHV4BzoWdv29ExvUbbNKy67VvRS8WWpE1FQThEA-r0" />
   <link rel="alternate" hreflang="en-us" href="<?php echo $zorexid;?>">
   
</head>
