<div class="card" style="display: inherit;">
                <div class="card-body">
				
                 <div class="fb-comments" data-href="http://localhost/zorexnid" data-width="100%" data-numposts="5"></div>

               

			   </div>
              </div>
					
			