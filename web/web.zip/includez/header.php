<?php
   error_reporting(0); 
   session_start();
   function ipost($var)
   {
   	$post = trim(strip_tags(htmlentities($_POST[$var])));
   	return $post;
   }
   $zorexid ="http://localhost/zorexid-lite";
   
   ?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta property="og:image" content="https://2.bp.blogspot.com/-b5HZBr4yS4c/XsPa4eadxTI/AAAAAAAAAtw/CyMNhFBlpQwRjEqKK57bnn_PwzguwHS9QCLcBGAsYHQ/s1600/zorex.jpg"/>
<meta name="keywords" content="zorexnid, bd smart nid maker, facebook id card maker, driving license maker, smart id card maker, zorexid, zorexnid, zorexid.cu.ma, zorex zisa, zorex zone, idcards.pw,Idcard.gq, Fake Bangladesh National id Card maker, Bd, fake, Nid, card, maker,  nidcard.gq, Facebook verification,  problem, Smart nid card maker ,genanator, Fake nid card make,bd fake identity card, how, to, bangladesh, bangladeshi, voter id card, zorexid.ml, maker, online, facebook solution bd fake identity, facebook, accept, disabled back bd fake card, Indian Nid Card Maker, Addhar Card, facebook id card generator, fake driving license maker, fake smart id card maker" />
<meta name="description" content="Fake id card maker for your facebook verification, bd smart nid maker, facebook id card maker, driving license maker, smart id card maker and online tools"/>
<meta name="author" content="Zorex Zisa"/>
<meta name="email" content="zorexzisa@gmail.com"/>
<meta name="copyright" content="Zorex Zisa"/>
<meta name="robots" content="index, all, follow"/>
<meta name="Revisit-After" content="1 Days"/>
<meta name="propeller" content="b0bb3b02ac5c462d83fb0ae53576e845">
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-152041744-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-152041744-1');
</script>


	<title><?php echo $title;?> - ZorexID</title>
	<meta charset="utf-8">
	<meta http-equiv="X-Frame-Options" content="deny">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" href="https://1.bp.blogspot.com/-8qGXm6oV_Hs/XsPa3RubfQI/AAAAAAAAAtk/_mzxeA6ghVgbP-DsGSsQlnXnlmfI8cMagCLcBGAsYHQ/s1600/fvicon.png">
	<link rel="stylesheet" type="text/css" href="<?php echo $zorexid;?>/stylez/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $zorexid;?>/stylez/animate.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $zorexid;?>/stylez/normalize.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $zorexid;?>/stylez/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $zorexid;?>/stylez/zx.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $zorexid;?>/stylez/card.css">
	
	<script src="https://app.rocketbots.io/facebook/chat/plugin/18293/114323626933890" async></script>

	
	
	
</head>
<body>

<script src="https://apis.google.com/js/platform.js"></script>
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/bn_IN/sdk.js#xfbml=1&version=v5.0"></script>

	<div class="imain"> 
<!-- Header Start-->
	<header class="iheader" data-wow-delay="0.3s" style="visibility: visible; -webkit-animation-delay: 0.3s; -moz-animation-delay: 0.3s; animation-delay: 0.3s;">
		<!-- Navigation Menu start -->
		<nav class="nav navbar-default imenu">
			<div class="container_fluid">
				<div class="navbar-header">
					<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".navbar-Collapse">
						<span class="sr-only">Toogle</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span> 
					</button>
					<a href="<?php echo $zorexid;?>"><img src="https://2.bp.blogspot.com/-47oFr5hVf3w/XsPa4XSXkxI/AAAAAAAAAts/bEnQtYVTCFsRUw4DuWQqUYnnOfOdvcZ6QCLcBGAsYHQ/s1600/logo.png"></a>
				</div>
				<div class="navbar-Collapse navbar-collapse navbar-right collapse menu_c">
					<ul class="nav navbar-nav" id="nav">
					
					    <li><a href="<?php echo $zorexid;?>">Home</a></li>
				        	
							<li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Make ID
        <span class="caret"></span></a>
        <ul class="dropdown-menu dropda">
										<li><a href="<?php echo $zorexid;?>/id/nid-front"> Old Nid Card Front</a></li>
										<li><a href="<?php echo $zorexid;?>/id/nid-full"> Old Nid Card Full</a></li>
										<li><a href="<?php echo $zorexid;?>/id/driving-license"> Driving License</a></li>
										<li> <a href="<?php echo $zorexid;?>/id/autistic-card"> Autistic ID Card</a></li>
					    				<li><a href="<?php echo $zorexid;?>/id/smart-card"> Smart Card </a></li>
					    				<li><a href="<?php echo $zorexid;?>/id/smart-hold"> Smart Card (Holding)</a></li>
					    				<li><a href="<?php echo $zorexid;?>/id/fbid"> Facebook ID Card </a></li>
										<li><a href="<?php echo $zorexid;?>/p?request">Request For Custom ID Card</a></li>
        </ul>
      </li>
						       <li><a href="<?php echo $zorexid;?>/p?about">About Us</a></li>
							   <li><a href="<?php echo $zorexid;?>/p?terms">Terms</a></li>
						       <li><a href="<?php echo $zorexid;?>/p?privacy">Privacy &amp; Policy</a></li>
											</ul>
											
				</div>
			</div>
		</nav>
		<!-- ../Navigation Menu End -->
		<script src="https://app.rocketbots.io/facebook/chat/plugin/18293/114323626933890" async></script>

	</header>
	<!-- ../Header End-->