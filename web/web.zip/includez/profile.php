<!-- ########################### Message Alart ######################### -->
<?php 
   error_reporting(0);
   if ( $_POST['name'] && $_POST['msg'] )
   {
   	$name = $_POST['name'];
   	$email = $_POST['email'];
   	$msg  = $_POST['msg'];
   	$dt = new DateTime('now', new DateTimezone('Asia/Dhaka'));
       $namd= $dt->format('j-F-Y-g-i-a-s');
   		$file    = "msg/$namd.php";
   
   	$date= $dt->format('g:i a F j, Y');
   		$f = fopen($file, "a");
   fwrite ($f,
   '<div class="alerts">
            <name>'.$name.'</name>
            Says,<br>
            <msg>'.$msg.'</msg>
            <br>	   
            <email>'.$email.'</email>
            <br>
            <time>'.$date.'</time>
         </div>');                 	
   ?>
<style> .alert{background-color: #2a2a2a;
   border-color: #1d1d1d;
   color: #0dce2e;
   text-shadow: 0 1px 0 #111;
   box-shadow: 0 0 12px rgba(0,0,0,.6);
   padding: 5px;
   border-width: 1px;
   border-style: solid;
   border-radius: .3125em;
   text-align: center;
   font-size:17px;
   font-family:Book Antiqua;
   max-width: 280px;}.closebtn{margin-left:15px;color:white;font-weight:bold;float:right;font-size:22px;line-height:20px;cursor:pointer;transition:.3s}.closebtn:hover{color:black} 
</style>
<center>
   <div class="alert">
      <span class="closebtn" onclick="this.parentElement.style.display='none';">×</span>
      <svg style="width:24px;height:24px" viewBox="0 0 24 24">
         <path fill="#0dce2e" d="M9,20.42L2.79,14.21L5.62,11.38L9,14.77L18.88,4.88L21.71,7.71L9,20.42Z" />
      </svg>
      Message has been Sent!
   </div>
</center>
<?php } ?>
<!-- ########################### Message Alart ######################### -->
<!-- Profile of Zorex -->   <br>
<div class="card card-profile text">
<div class="card-avatar">
   <a href="#pablo">
   <img class="img" alt="Zorex Zisa" src="<?php echo $zorexid;?>/stylez/zorex.jpg">
   </a>
</div>
<div class="card-body">
<h6 class="card-category text-gray">CEO / Founder</h6>
<h4 class="card-title">Zorex Zisa</h4>
<p class="card-description">
   I am a web developer, programmer and graphics designer. If you need any kind of website or help, feel free to contact me. <br>
   <a style="color: #0686F6;" href="http://www.facebook.com/zorexzisa"><img src="http://icons.iconarchive.com/icons/yootheme/social-bookmark/24/social-facebook-box-blue-icon.png"> fb.com/zorexzisa</a><br>
   <a style="color: #F61C06;" href="mailto:zorexzisa@gmail.com"><img width="24px" src="http://icons.iconarchive.com/icons/ncrow/mega-pack-1/24/Gmail-icon.png"> zorexzisa@gmail.com</a>
</p>
<!--Send Message -->
<button class="btn btn-primary btn-round" data-toggle="modal" data-target="#loginModal">
   Message
   <div class="ripple-container"></div>
</button>
<div class="modal fade" id="loginModal" tabindex="-1" role="" style="display: none;" aria-hidden="true">
   <div class="modal-dialog modal-login" role="document">
      <div class="modal-content">
         <div class="">
            <div class="modal-header">
               <div class="card-header card-header-primary text-center">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                  x
                  </button>
                  <h4 class="card-title">Quick Message</h4>
               </div>
            </div>
            <div class="modal-body">
               <form action="" method="post" class="form">
                  <p class="description text-center">Send Message To Admin</p>
                  <div class="card-body">
                     <div class="row">
                        <div class="col-md-12">
                           <div class="form-group bmd-form-group">
                              <label class="bmd-label-floating">Name</label>
                              <input type="text" name="name" class="form-control">
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-12">
                           <div class="form-group bmd-form-group">
                              <label class="bmd-label-floating">Email Adress</label>
                              <input type="text" name="email" class="form-control">
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-12">
                           <div class="form-group">
                              <label>Your Message</label>
                              <div class="form-group bmd-form-group">
                                 <textarea name="msg" class="form-control" rows="5"></textarea>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
            </div>
            <div class="modal-footer justify-content-center text">                    
            <button class="btn btn-primary btn-round" type="submit">Submit</button>
            </div>
            </form>	 
         </div>
      </div>
   </div>
</div>
<!--Send Message -->
