            <div class="modal fade" id="terms" tabindex="-1" role="" style="display: none;" aria-hidden="true">
               <div class="modal-dialog modal-login" role="document">
                  <div class="modal-content">
                     <div class="">
                        <div class="modal-header">
                           <div class="card-header card-header-primary text-center">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                              x
                              </button>
                              <h4 class="card-title">Terms and Conditions For ID Card</h4>
							  <p class="card-category">You can use this cards only in following conditions</p>
                           </div>
                        </div>
                        <div class="modal-body">				
                            <p>✅ You can only use this any kind of media verification, educational and entertainment perpose<p>
							<p>❌ This card is not for any kind of offline use</p>
							<p>❌ Don't use it for any kind of illigal or hacking activities.</p>
							<p>✔ We are not responsible for any kind of illigal or spam activities caused by your actions.</p>      
                        </div>
						
                        <div class="modal-footer justify-content-center text">                    
                           <button class="btn btn-primary btn-round" data-dismiss="modal" aria-hidden="true" type="button">Close</button>                           
                        </div>
                     </div>
                  </div>
               </div>
            </div>





<div id="popup1" class="popup">

      <div id="fblike">
         <h1>Terms and Conditions For ID Card</h1>
      </div>
      <div id="closeBox">
         <p>You can use this cards only in following conditions</p>
      </div>
      <div class="contentpop">
         <p>You can use this any kind of media verification, educational and entertainment perpose
         <p>
         <p>Don't use it for any kind of illigal or haking activities.</p>
         <p>We are not responsible for any kind of illigal or spam activities caused by your actions.</p>
      </div>
     
	 <div id="closeBox" style="height: 41px;">
         <a href="#" class="closex">Close</a>
      </div>
</div>
<a href="#" class="close-popup"></a>
<style>
 .closex {
   text-decoration: none;
   color: #fff;
   font-size: 11px;
   font-weight: 700;
   background-color: #5d76aa;
   border: 1px solid #2a437e;
   display: block;
   -webkit-box-shadow: inset 0 1px 0 #8a9cc2;
   -moz-box-shadow: inset 0 1px 0 #8a9cc2;
   box-shadow: inset 0 1px 0 #8a9cc2;
   padding: 3px 6px;
   position: absolute;
   right: 10px;
   top: 10px;
   z-index: 4;
   cursor: pointer;
   }
   .closex:hover {
   color: #fff;
   }
 #fblike h1  { background-color: #6d84b4;
   font-size: 14px;
   color:
   #fff;
   padding: 5px 10px;
   margin: 0;
   font-family: "lucida grande", tahoma, verdana, arial, sans-serif;
   letter-spacing: normal;
   border-bottom: 1px solid
   #425693;
   }
   #closeBox p {
   color: #111;
   font: 13px/20px Arial, sans-serif;
   padding-left: 10px;
   padding-right: 10px;
   }
   .contentpop p {
   color: #111;
   font: 13px/20px Arial, sans-serif;
   padding-left: 10px;
   padding-right: 10px;
   }
   #closeBox {
   background-color: 
   #f2f2f2;
   position: relative;
   padding: 0;
   font-family: "lucida grande", tahoma, verdana, arial, sans-serif;
   border-top: 1px solid
   #ccc;
   border-bottom: 1px solid
   #ccc;
   z-index: 3;
   padding-top: 5px;
   }
  

.popup {
  position: fixed;
  padding: 10px;
  max-width: 500px;
  border-radius: 10px;
  top: 50%;
  left: 50%;
  transform: translate(-50%,-50%);
  background: rgba(255,255,255,.9);
  visibility: hidden;
  opacity: 0;
  /* "delay" the visibility transition */
  -webkit-transition: opacity .5s, visibility 0s linear .5s;
  transition: opacity .5s, visibility 0s linear .5s;
  z-index: 1;
  
   background: #fff;
   border-radius: 5px;
   width: 50%;
   
   border: 4px solid rgba(0,0,0,0.445);
   -webkit-border-radius: 7px;
   -moz-border-radius: 7px;
   border-radius: 7px;
   padding: 0;
   font-family: "lucida grande", tahoma, verdana, arial, sans-serif;
}
@media screen and (max-width: 700px){
   .popup{
   width: 80%;
   }
   }
.popup:target {
  visibility: visible;
  opacity: 1;
  /* cancel visibility transition delay */
  -webkit-transition-delay: 0s;
  transition-delay: 0s;
}
.popup .close {
  position: absolute;
  right: 5px;
  top: 5px;
  padding: 5px;
  color: #000;
  transition: color .3s;
  font-size: 2em;
  line-height: .6em;
  font-weight: bold;
}
.popup .close:hover {
  color: #00E5EE;
}

.close-popup {
  background: rgba(0,0,0,.7);
  cursor: default;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  opacity: 0;
  visibility: hidden;
  /* "delay" the visibility transition */
  -webkit-transition: opacity .5s, visibility 0s linear .5s;
  transition: opacity .5s, visibility 0s linear .5s;
}
.popup:target + .close-popup{  
  opacity: 1;
  visibility: visible;
  /* cancel visibility transition delay */
  -webkit-transition-delay: 0s;
  transition-delay: 0s;
}
</style>