<div class="card card-profile text">
   <h4 class="lis">Make More</h4>
   <style>
      #block {
      padding: 2px ;
      float: left;
      }
      .lis {
      font-family: 'Exo 2' , 'AdorshoLipi';
      padding: 8px;
      font-size: 17px;
      color: 
      #444;
      border-bottom: 1px solid
      #ddd;
      border-bottom-width: 1px;
      border-width: 1px 0;
      background: linear-gradient(to bottom,
      #ffffff 0%,#e0e0e0 50%,
      #ffffff 100%);
      text-shadow: 1px 1px 0px
      #FFF;
      }
      .list_blok ul li {
      padding: 7px;
      font-size: 14px;
      font-weight: normal;
      list-style: none;
      border-bottom: 1px solid  #f2f2f2;
      float: left;
      }
      #i-arrow {
      display: inline-block;
      background-image: url(<?php echo $zorexid;?>/stylez/files/garrow.png);
      background-size: 100%100%;
      width: 17px;
      height: 17px;
      background-position: center;
      background-repeat: no-repeat;
      margin-right: 4px;
      margin-bottom: -2px;
      }
      .list_blok li a {
      color: 
      #444;
      font-weight: normal;
      }
   </style>
   <div id="block" class="list_blok">
      <ul><li><i id="i-arrow"></i><a href="<?php echo $zorexid;?>/corona-live-update"> Corona Live Update</a></li>
      <li><i id="i-arrow"></i><a href="<?php echo $zorexid;?>/id/nid-front"> Old Nid Card Front</a></li>
      <li><i id="i-arrow"></i> <a href="<?php echo $zorexid;?>/id/nid-full"> Old Nid Card Full</a></li>
      <li><i id="i-arrow"></i><a href="<?php echo $zorexid;?>/id/driving-license"> Driving License</a></li>
      <li><i id="i-arrow"></i> <a href="<?php echo $zorexid;?>/id/autistic-card"> Autistic ID Card</a></li>
      <li><i id="i-arrow"></i><a href="<?php echo $zorexid;?>/id/smart-card"> Smart Card </a></li>
      <li><i id="i-arrow"></i><a href="<?php echo $zorexid;?>/id/smart-hold"> Smart Card (Holding)</a></li>
      <li><i id="i-arrow"></i><a href="<?php echo $zorexid;?>/id/smart-card-png"> Smart Card (PNG)</a></li>
      <li><i id="i-arrow"></i><a href="<?php echo $zorexid;?>/id/fbid"> Facebook ID Card </a></li>
      <li><i id="i-arrow"></i><a href="<?php echo $zorexid;?>/p?request">Request For Custom ID Card</a></li>
   </div>
</div>
