<?php
$siturl = "http://localhost/zorexnid";
?>