




<?php 
error_reporting(0);
foreach (glob("msg/*.php") as $file1)
foreach (glob("id/msg/*.php") as $file2)
{
    include $file2;
    include $file1;
}

?>
<style>
   .alerts{
   max-width: 325px;
   padding: 20px;
   box-shadow: 0 2px 5px rgba(0,0,0,.4);
   margin: 2% auto;
   background-color: #2a2a2a;
   border-color: #1d1d1d;
   color: #fff;
   text-shadow: 0 1px 0 #111;
   box-shadow: 0 0 12px rgba(0,0,0,.6);
   border-width: 1px;
   border-style: solid;
   border-radius: .3125em;}
   .closebtn{margin-left:15px;color:blue;font-weight:bold;float:right;font-size:22px;line-height:20px;cursor:pointer;transition:.3s}.closebtn:hover{color:black} 
   name{color: #fb0ed3;font-family:papyrus;}
   msg{color: #42ee15;font-family:Book Antiqua;}
   time{font-family:Microsoft Yi Baiti;}
   email{color:#1cf4f7; font-family:Sakkal Majalla;}
</style>
