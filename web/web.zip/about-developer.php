<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:b="http://www.google.com/2005/gml/b" xmlns:data="http://www.google.com/2005/gml/data" xmlns:expr="http://www.google.com/2005/gml/expr" class="no-touch">

<head>
   <link href='https://www.blogger.com/static/v1/widgets/2549344219-widget_css_bundle.css' rel='stylesheet' type='text/css'/>
   <link href='https://i.imgur.com/y31kEhf.jpg' rel='icon' type='image/x-icon'/>
   <link href='//css.leanhduc.pro.vn/mouse_cursor.css' rel='stylesheet' type='text/css'/>
   <meta content='width=device-width, initial-scale=1' name='viewport'/>
   <script type='text/javascript'>
      //<![CDATA[
      function loadCSS(e, t, n) { "use strict"; var i = window.document.createElement("link"); var o = t || window.document.getElementsByTagName("script")[0]; i.rel = "stylesheet"; i.href = e; i.media = "only x"; o.parentNode.insertBefore(i, o); setTimeout(function () { i.media = n || "all" }) }
      loadCSS("https://use.fontawesome.com/releases/v5.1.0/css/all.css");loadCSS("https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Condensed:300,400,700|Roboto+Slab:400,500,700");loadCSS("//cdn.jsdelivr.net/gh/hung1001/blog@c30405f/smart/lib/font-awesome/css/all.css");loadCSS("https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css");loadCSS("https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese");loadCSS("https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese");
      //]]>
   </script>
   <meta charset='utf-8'/>
   <!-- Meta Data -->
   <meta content='IE=edge' http-equiv='X-UA-Compatible'/>
   <meta content='width=device-width, initial-scale=1, shrink-to-fit=no' name='viewport'/>
   <meta content='telephone=no' name='format-detection'/>
   <meta content='address=no' name='format-detection'/>
   <meta content='Zorex Zisa' name='author'/>
   <meta content='Zorex Zisa | Website Sharing Tips Facebook, Blogspot, Code, Template, Windows, Good Tips, New Technology, Sharing Knowledge General, Computer Tips, Windows 10 Tips, Facebook Tips, Youtube Tips, Tips Blogger, Blogspot Tips, Internet Tips, Tips for Money, Facebook Cover, Blogger Template, Blogspot Template, Website Design, Blogger Design, v.v...' name='description'/>
   <meta content='Zorex Zisa, Zorex Blog, Info Zorex Zisa, CV Zorex Zisa, Website Sharing Tips, Facebook, Blogspot, Code, Template, Windows, Good Tips, New Technology, Sharing Knowledge, Tips Computer Tips, Windows 10 Tips, Facebook Tips, YouTube Tips, Blogger Tips, Blogspot Tips, Internet Tricks, Internet Tips, Monetization Tips, Facebook Cover Images, Blogger Template, Blogspot Template, Website Design, Design Blogger, etc.' name='keywords'/>
   <!-- Twitter data -->
   <meta content='summary_large_image' name='twitter:card'/>
   <meta content='@ZorexZisa' name='twitter:site'/>
   <meta content='Zorex Zisa' name='twitter:title'/>
   <meta content='Zorex Zisa | Website Sharing Tips Facebook, Blogspot, Code, Template, Windows, Good Tips, New Technology, Sharing Knowledge General, Computer Tips, Windows 10 Tips, Facebook Tips, Youtube Tips, Tips Blogger, Blogspot Tips, Internet Tips, Tips for Money, Facebook Cover, Blogger Template, Blogspot Template, Website Design, Blogger Design, v.v...' name='twitter:description'/>
   <meta content='https://i.imgur.com/y31kEhf.jpg' name='twitter:image'/>
   <!-- Open Graph data -->
   <meta content='Phú Groups - About' property='og:title'/>
   <meta content='website' property='og:type'/>
   <meta content='/' property='og:url'/>
   <meta content='https://i.imgur.com/y31kEhf.jpg' property='og:image'/>
   <meta content='Zorex Zisa | Website Sharing Tips Facebook, Blogspot, Code, Template, Windows, Good Tips, New Technology, Sharing Knowledge General, Computer Tips, Windows 10 Tips, Facebook Tips, Youtube Tips, Tips Blogger, Blogspot Tips, Internet Tips, Tips for Money, Facebook Cover, Blogger Template, Blogspot Template, Website Design, Blogger Design, vv.v...' property='og:description'/>
   <meta content='Zorex Zisa' property='og:site_name'/>
   <!-- Favicons -->
   <link href='https://i.imgur.com/y31kEhf.jpg' rel='apple-touch-icon' sizes='144x144'/>
   <link href='https://i.imgur.com/y31kEhf.jpg' rel='apple-touch-icon' sizes='114x114'/>
   <link href='https://i.imgur.com/y31kEhf.jpg' rel='apple-touch-icon' sizes='72x72'/>
   <link href='https://i.imgur.com/y31kEhf.jpg' rel='apple-touch-icon' sizes='57x57'/>
   <link href='https://i.imgur.com/y31kEhf.jpg' rel='shortcut icon' type='image/png'/>
   <!-- Styles -->
   <link href='https://cv.leanhduc.pro.vn/assets/styles/style.css' rel='stylesheet' type='text/css'/>
   <link href='https://cv.leanhduc.pro.vn/assets/demo/style-demo.css' rel='stylesheet' type='text/css'/>
   <link href='https://cv.leanhduc.pro.vn/assets/styles/dark-mod.css' rel='stylesheet' type='text/css'/>
   <title>
      Zorex Zisa | About
   </title>
   <!-- Start writing Css for usb -->
   <style id='page-skin-1' type='text/css'>
      <!--
         /* Insert CSS here */
         
         -->
   </style>
</head>


<body class="bg-triangles">
<!-- Preloader -->
<style type="text/css"> iframe {background-color: #f9f9f900 !important;}   #wh-widget-send-button {        margin: 0 !important;        padding: 0 !important;        position: fixed !important;        z-index: 16000160 !important;        bottom: 0 !important;        text-align: center !important;        height: 90px;        width: 60px;        visibility: visible;        transition: none !important;    }    #wh-widget-send-button.wh-widget-right {        right: 0;    }    #wh-widget-send-button.wh-widget-left {        left: 10px;    }    #wh-widget-send-button iframe {        width: 100%;        height: 100%;        border: 0;    }div.clear {    clear: both;}</style><div class="preloader" style="opacity: 0.7; z-index: -1;">
<div class="preloader__wrap">
<div class="circle-pulse" style="opacity: 0.7;">
<div class="circle-pulse__1"></div>
<div class="circle-pulse__2"></div>
</div>
<div class="preloader__progress"><span style="width: 100%;"></span></div>
</div>
</div>
<main class="main">
<div class="container gutter-top">
<div class="row sticky-parent">
<!-- Sidebar -->
<aside class="col-12 col-md-12 col-xl-3">
<div class="sidebar box shadow pb-0 sticky-column">
<svg class="avatar avatar--180" viewBox="0 0 188 188">
<g class="avatar__box">
<image height="100%" width="100%" xlink:href="https://i.imgur.com/i1Amanr.jpg"></image>
</g>
</svg>
<div class="text-center">
<a href="https://m.facebook.com/zorex.zisa"><h3 class="title title--h3 sidebar__user-name"><span class="weight--500"></span>Kazi Firoz Asif (Zorex Zisa) <i class="fa fa-check-circle" style="color: #118ff9;" title="Verified Author"></i></h3></a>
<div class="badge badge--light">Developer &amp; Designer</div>
<!-- Social -->
<div class="social">
<a class="social__link" href="https://www.facebook.com/zorex.zisa"><i class="font-icon icon-facebook"></i></a>
<a class="social__link" href="https://www.instagram.com/zorexzisa"><i class="font-icon icon-instagram"></i></a>
<a class="social__link" href="https://github.com/"><i class="font-icon icon-github"></i></a>
<a class="social__link" href="https://twitter.com/ZorexZisa"><i class="font-icon icon-twitter"></i></a>
</div>
</div>
<div class="sidebar__info box-inner box-inner--rounded">
<ul class="contacts-block">
<li class="contacts-block__item" data-placement="top" data-toggle="tooltip" title="" data-original-title="Birthday">
<i class="font-icon icon-calendar"></i>May 5th, 2000
							    </li>
<li class="contacts-block__item" data-placement="top" data-toggle="tooltip" title="" data-original-title="Address">
<i class="font-icon icon-location"></i>Dhaka, Bangladesh
							    </li>
<li class="contacts-block__item" data-placement="top" data-toggle="tooltip" title="" data-original-title="E-mail">
<a href="mailto:ZorexZisa@gmail.com"><i class="font-icon icon-envelope"></i>zorexzisa@gmail.com</a>
</li>
<li class="contacts-block__item" data-placement="top" data-toggle="tooltip" title="" data-original-title="Phone">
<i class="font-icon icon-phone"></i>+8801772012777
							    </li>
</ul>
</div>
</div>
</aside>
<!-- Content -->
<div class="col-12 col-md-12 col-xl-9">
<div class="box shadow pb-0">
<!-- Menu -->
<div class="circle-menu">
<div class="hamburger">
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
</div>
</div>
<div class="inner-menu js-menu">
<ul class="nav" style="width: 0px;">
<li class="nav__item" style="opacity: 0.7; transform: matrix(1, 0, 0, 1, 70, 0);"><a class="active" href="http://zoogle.cf">Zoogle</a></li>
<li class="nav__item" style="opacity: 0.7; transform: matrix(1, 0, 0, 1, 70, 0);"><a class="active" href="http://zorexlogo.ml">Zorexlogo</a></li>
<li class="nav__item" style="opacity: 0.7; transform: matrix(1, 0, 0, 1, 70, 0);"><a class="active" href="http://www.zorexid.cu.ma/">Zorexid</a></li>
<li class="nav__item" style="opacity: 0.7; transform: matrix(1, 0, 0, 1, 70, 0);"><a class="active" href="http://zorextune.ga/">Zorextune</a></li>

</ul>
</div>
<!-- About -->
<div class="pb-0 pb-sm-2">
<h1 class="title title--h1 title__separate">About Me</h1>
<p>I am Kazi Firoz Asif, also known as Zorex Zisa, a professional Developer &amp; Designer. Web development is my hobby,
I also like to create various types of useful web applications using php. I'm working as a web developer for two years.</p>
<p>Currently, I am studying as a HSC student. I usually design and develop website as required by people. Besides, I also design logo, banner, ads, video content etc. Recently I'm learning about SEO and Marketing for becoming an expert in these fields</p>
</div>
<!-- What -->
<div class="box-inner pb-0">
<h2 class="title title--h3">What I'm Doing</h2>
<div class="row">
<!-- Case Item -->
<div class="col-12 col-lg-6">
<div class="case-item box box__second">
<img alt="" class="case-item__icon" src="http://icons.iconarchive.com/icons/aha-soft/standard-portfolio/48/Graphic-designer-icon.png">
<div>
<h3 class="title title--h5">Web Design</h3>
<p class="case-item__caption">The most modern and high-quality design made at a professional level.</p>
</div>
</div>
</div>
<!-- Case Item -->
<div class="col-12 col-lg-6">
<div class="case-item box box__second">
<img alt="" class="case-item__icon" src="http://icons.iconarchive.com/icons/webalys/kameleon.pics/48/Coding-Html-icon.png">
<div>
<h3 class="title title--h5">Web Development</h3>
<p class="case-item__caption">High-quality development of sites at the professional level.</p>
</div>
</div>
</div>
<!-- Case Item -->
<div class="col-12 col-lg-6">
<div class="case-item box box__second">
<img alt="" class="case-item__icon" src="http://icons.iconarchive.com/icons/graphicloads/business/48/market-rising-icon.png">
<div>
<h3 class="title title--h5">SEO and Marketing</h3>
<p class="case-item__caption">Professional development of applications for iOS and Android.</p>
</div>
</div>
</div>
<!-- Case Item -->
<div class="col-12 col-lg-6">
<div class="case-item box box__second">
<img alt="" class="case-item__icon" src="https://i.imgur.com/msIZOQ7.png">
<div>
<h3 class="title title--h5">Graphics Design</h3>
<p class="case-item__caption">I design logo, banner, ads, video content and other graphics designing work</p>
</div>
</div>
</div>

</div>
</div>



</div>

<!-- Footer -->
<footer class="footer">Copyright ©
                      <a href="https://m.facebook.com/zorex.zisa/">Zorex Zisa </a><i class="fa fa-check-circle" style="color: #118ff9;" title="Verified Author"></i>
</footer>
</div>
</div>
</div>
</div>
</main>
<div class="back-to-top" style="display: none;"></div>
<!-- SVG masks -->
<svg class="svg-defs">
<clipPath id="avatar-box">
<path d="M1.85379 38.4859C2.9221 18.6653 18.6653 2.92275 38.4858 1.85453 56.0986.905299 77.2792 0 94 0c16.721 0 37.901.905299 55.514 1.85453 19.821 1.06822 35.564 16.81077 36.632 36.63137C187.095 56.0922 188 77.267 188 94c0 16.733-.905 37.908-1.854 55.514-1.068 19.821-16.811 35.563-36.632 36.631C131.901 187.095 110.721 188 94 188c-16.7208 0-37.9014-.905-55.5142-1.855-19.8205-1.068-35.5637-16.81-36.63201-36.631C.904831 131.908 0 110.733 0 94c0-16.733.904831-37.9078 1.85379-55.5141z"></path>
</clipPath>
<clipPath id="avatar-hexagon">
<path d="M0 27.2891c0-4.6662 2.4889-8.976 6.52491-11.2986L31.308 1.72845c3.98-2.290382 8.8697-2.305446 12.8637-.03963l25.234 14.31558C73.4807 18.3162 76 22.6478 76 27.3426V56.684c0 4.6805-2.5041 9.0013-6.5597 11.3186L44.4317 82.2915c-3.9869 2.278-8.8765 2.278-12.8634 0L6.55974 68.0026C2.50414 65.6853 0 61.3645 0 56.684V27.2891z"></path>
</clipPath>
</svg>
<!-- JavaScripts -->
<script src="index_files/drop_heart.js"></script>
<script src="index_files/jquery-3.js"></script>
<script src="index_files/plugins.js"></script>
<script src="index_files/common.js"></script>
<script src="index_files/plugins-demo.js"></script>
<style>
html,body{cursor:url("https://i.imgur.com/5v5M8gh.png"), auto;}
a:hover{cursor:url("https://i.imgur.com/IXULuQ1.png"), auto;}
</style>
<div class="navbar no-items section" id="navbar"></div>
<!-- WhatsHelp.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            facebook: "zorexzone", // Facebook page ID
            call_to_action: "Message us", // Call to action
            position: "left", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "getbutton.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /WhatsHelp.io widget -->

		</body><!-- End of web display --></html>