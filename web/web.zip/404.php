	 <center> <a href='./'><h1><font color='white'>404 Not Found1!</font></h1></a><center>
	 
	 
<meta forua="true" http-equiv="Cache-Control" content="max-age=0"/><meta http-equiv="refresh" content="0;URL=/index.php"/>

