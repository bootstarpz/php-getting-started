<div class="iheader"> </div>
<footer class="ifooter">
		<div class="container_fluid">
			<div class="text-center">				
				<h4 style="text-shadow: #000 0px 2px 7px;font-size: 16px;">© 2020 | <a href="<?php echo $zorexid;?>">ZorexID.cu.ma</a> </h4>	
				
					<h6 style="color:#ffffff;">Developed By <a title="zorex" href="https://m.facebook.com/zorexz"><font color="#00ff00">Zorex Zisa </font></a></h6>
					<br>

<style>
#LTFcounter{transition: 0.5s;width: 50px;border:0px #ffffff hidden;box-shadow: 0px 1px rgba(255, 255, 255, 0.3) inset, 0px 0px 1px 1px rgba(255, 255, 255, 0.1) inset, 0px 2px 10px rgba(17, 18, 17, 0.5);border-radius: 4px;"}
#LTFcounter:hover {width: 150px;}
</style>
		<center><a href="https://livetrafficfeed.com/website-counter" data-time="Asia%2FDhaka" data-root="0" id="LTF_counter_href">Free Blog Counter</a><script type="text/javascript" src="//cdn.livetrafficfeed.com/static/static-counter/live.v2.js"></script><noscript><a href="https://livetrafficfeed.com/website-counter">Free Blog Counter</a></noscript></center>			
					<br>
			
<div style="margin:10px;">


			
					
				
				<h4 style="text-shadow: #000 0px 2px 7px;font-size: 14px;">
	<a title="About" href="<?php echo $zorexid;?>/p?about"> About   </a> |
	<a title="Terms and Conditions" href="<?php echo $zorexid;?>/p?terms"> Terms and Conditions</a> |
	<a title="DMCA" href="<?php echo $zorexid;?>/p?privacy"> Privacy &amp; Policy </a>	</h4>
			</div>
		
			
	</div></footer>

<!-- ../Footer start -->
<script src="<?php echo $zorexid;?>/stylez/jquery.min.js"></script>
<script src="<?php echo $zorexid;?>/stylez/bootstrap.min.js"></script>






</body></html>