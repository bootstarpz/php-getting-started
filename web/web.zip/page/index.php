<?php include "../includez/header.php";?>
<!-- Section start -->
<div class="container-fluid">
   <div class="row">
      <div class="col-md-8">
        
		<div class="card">
            <div class="card-header card-header-primary">
               <h4 class="card-title">Facebook ID Maker</h4>
               <p class="card-category">Complete your information</p>
            </div>
            <div class="card-body" style="text-align: left;">
             
<div style="padding:10px">			
			<?php 
			if($_GET['p'] == 'about') {include "about.php";}
			if($_GET['p'] == 'about') {include "contact.php"; }
			if($_GET['p'] == 'terms') {include "terms.php"; }
		    
			?>
			   
</div>             
            </div>
         </div>
        
		<!-- Advertise Bottom-->
         <?php include "../includez/ad-bottom.php";?>
         <!-- Advertise Bottom end-->
         <!-- Profile of Zorex --> 
         <?php include "../includez/profile.php";?>		  
         <!-- Profile of Zorex -->   
      </div>
   </div>
   <!-- Advertise Side-->
   <?php include "../includez/ad-side.php";?>
</div>
</div>
</div>
<?php  include "../includez/footer.php";?>
